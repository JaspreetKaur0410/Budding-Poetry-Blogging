/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* global order_id */

const paymentinitiate = () => {
    console.log("Payment Started");
    let amount = $("#s_amount").val();
    console.log(amount);
    $.ajax({
        type: 'POST',
        url: 'subscribe/createorder.htm',
        data: JSON.stringify({amount: amount, info: 'order_request'}),
        contentType: 'application/json',
        dataType: 'json',
        success: function (response) {
            console.log(response);
            if (response.status == "created") {
                alert("me");
                let options = {
                    key: 'rzp_test_CpSq9oajzMTyc1',
                    amount: response.amount,
                    currency: 'INR',
                    description: 'Subscription',
                    order_id: response.id,
                    handler: function (response) {
                        console.log(response.razorpay_payment_id);
                        console.log(response.razorpay_order_id);
                        console.log(response.razorpay_signature);
                        
                        updatePaymentOnServer(
                                response.razorpay_payment_id,
                                response.razorpay_order_id,
                                "paid"
                                );
                    }
                };
                let rzp = new Razorpay(options);
                rzp.on('payment.failed', function (response) {
                    alert(response.error.code);
                });
                rzp.open();
            }
        },
        error: function (error) {
            console.log("error");
        }
    }

    );
};

function updatePaymentOnServer(payment_id, order_id, status){
    alert("here");
$.ajax({
    type: 'POST',
    url: 'subscribe/upadetpayment.htm',
    data: JSON.stringify({payment_id: payment_id, order_id: order_id,status:status}),
    contentType: 'application/json',
    dataType: 'json',
    success:function(response){
    }
});
}

