/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.buddingpoetry.pojo;

import java.util.ArrayList;
import java.util.List;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Transient;
import org.hibernate.annotations.DynamicUpdate;
import org.hibernate.annotations.OptimisticLockType;
import org.hibernate.annotations.OptimisticLocking;

/**
 *
 * @author jaspr_000
 */
@Entity
@OptimisticLocking(type = OptimisticLockType.DIRTY)
@Table(name = "item")
@DynamicUpdate
public class Item {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private int id;
    
    @OneToOne
    private Book item_book;
    
    @ManyToOne
    private User buy_user_item;
    
    private int quantity;
    
    private int cost;
    /*********************/
  
    @ManyToOne
    private CartOrder cartorder;
    /**********************/
    
    public Item(){
        
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public Book getItem_book() {
        return item_book;
    }

    public void setItem_book(Book item_book) {
        this.item_book = item_book;
    }

    public User getBuy_user_item() {
        return buy_user_item;
    }

    public void setBuy_user_item(User buy_user_item) {
        this.buy_user_item = buy_user_item;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public int getCost() {
        return cost;
    }

    public void setCost(int cost) {
        this.cost = cost;
    }

    public CartOrder getCartorder() {
        return cartorder;
    }

    public void setCartorder(CartOrder cartorder) {
        this.cartorder = cartorder;
    }

    
    @Override
    public String toString() {
        return item_book.getBook_title();
    }  
}
