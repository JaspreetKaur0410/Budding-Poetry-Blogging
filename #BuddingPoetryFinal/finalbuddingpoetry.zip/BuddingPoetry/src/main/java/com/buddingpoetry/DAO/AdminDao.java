/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.buddingpoetry.DAO;

import static com.buddingpoetry.DAO.DAO.getSession;
import com.buddingpoetry.pojo.AdminRequests;
import com.buddingpoetry.pojo.Contest;
import com.buddingpoetry.pojo.Participants;
import com.buddingpoetry.pojo.PostCategory;
import com.buddingpoetry.pojo.PostCategoryList;
import com.buddingpoetry.pojo.User;
import java.util.ArrayList;
import java.util.List;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.criterion.Restrictions;

/**
 *
 * @author jaspr_000
 */
public class AdminDao extends DAO {

    public ArrayList<PostCategory> addPostCategoroies(String[] categoriesname, PostCategoryList categorylist) {

        ArrayList<PostCategory> postcategoriesaddedbyadmin = categorylist.getPostcategorieslist();
        PostCategory postcategory = new PostCategory();
        for (String postcategoryname : categoriesname) {
            postcategory.setCategoryname(postcategoryname);
            postcategoriesaddedbyadmin.add(postcategory);
            System.out.println("%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%" + postcategoryname + "%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%");
        }
        System.out.println("%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%" + postcategoriesaddedbyadmin + "%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%");
        //Session session = getSession();
        begin();
        getSession().save(postcategory);
        commit();
        return postcategoriesaddedbyadmin;

    }

    public ArrayList<AdminRequests> getAllAdminRequests() {
        ArrayList<AdminRequests> all_adminrequests_list = new ArrayList<>();
        begin();
        Criteria criteria = getSession().createCriteria(AdminRequests.class);
        all_adminrequests_list = (ArrayList<AdminRequests>) criteria.list();
        commit();
        return all_adminrequests_list;
    }

    public AdminRequests getRequestById(int request_id) {

        for (AdminRequests ar : getAllAdminRequests()) {
            if (String.valueOf(ar.getAdmin_request_id()).equals(String.valueOf(request_id))) {
                return ar;
            }
        }
        return null;
    }

    public String updateApprrovalStatus(AdminRequests adminrequest, String approvalstatus) {
        try {
            adminrequest.setApprovalstatus(approvalstatus);
            begin();
            getSession().save(adminrequest);
            commit();
            return "Admin Approval Updated";
        } catch (Exception e) {
            return "Something Went Wrong";
        }
    }

    public Contest createContest(Contest b_contest) {
        try {
            Contest contest = new Contest();
            contest.setContestname(b_contest.getContestname());
            contest.setDescription(b_contest.getDescription());
            contest.setTopic(b_contest.getTopic());
            begin();
            getSession().save(contest);
            commit();
            return contest;
        } catch (Exception e) {
            return null;
        }
    }

    public Contest getContestById(int contestid) {
        try {
            Criteria crit = getSession().createCriteria(Contest.class);
            crit.add(Restrictions.eq("contest_id", contestid));
            Contest contest = (Contest) crit.uniqueResult();
            System.out.println("++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++"+contest);
            return contest;
        } catch (Exception e) {
            return null;
        }
    }

    public List<Contest> getAllContests() {
        try {
            ArrayList<Contest> contest_list = new ArrayList<>();
            begin();
            Criteria criteria = getSession().createCriteria(Contest.class);
            contest_list = (ArrayList<Contest>) criteria.list();
            commit();
            return contest_list;
        } catch (Exception e) {
            return null;
        }
    }

    public List<Participants> getContestParticipants(Contest contest) {
        try {
            ArrayList<Participants> contest_partcipant_list = new ArrayList<>();
            begin();
            Criteria criteria = getSession().createCriteria(Participants.class);
            criteria.createAlias("participant_contest", "participant_contestid");
            criteria.add(Restrictions.eq("participant_contestid.contest_id", contest.getContest_id()));
            contest_partcipant_list = (ArrayList<Participants>) criteria.list();
            commit();
            return contest_partcipant_list;
        } catch (Exception e) {
            return null;
        }
    }

    public Participants getParticipanyById(int participant_id) {
        try {
            begin();
            Criteria criteria = getSession().createCriteria(Participants.class);
            criteria.add(Restrictions.eq("participant_id", participant_id));
            Participants participant = (Participants) criteria.uniqueResult();
            commit();
            return participant;
        } catch (Exception e) {
            return null;
        }
    }

    public String declareWinner(Contest contest, Participants winner) {
        try {
            contest.setWinner(winner);
            begin();
            getSession().update(contest);
            commit();
            return "Winner Declared";
        } catch (Exception e) {
            return e.getMessage();
        }
    }
    
    public boolean isAdminExist(User user, UserDao userdao){
        for(User u:userdao.getAllUsers()){
            if(String.valueOf(u.getRole()).equals("admin")){
                return true;
            }
        }
        return false;
    }

}
