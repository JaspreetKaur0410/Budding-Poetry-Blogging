/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.buddingpoetry.controller;

import com.buddingpoetry.DAO.AdminDao;
import com.buddingpoetry.DAO.CategoryDao;
import com.buddingpoetry.DAO.SubscriptionDao;
import com.buddingpoetry.DAO.UserDao;
import com.buddingpoetry.pojo.AdminRequests;
import com.buddingpoetry.pojo.Contest;
import com.buddingpoetry.pojo.Participants;
import com.buddingpoetry.pojo.PostCategory;
import com.buddingpoetry.pojo.PostCategoryList;
import com.buddingpoetry.pojo.User;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.http.HttpHeaders;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;
import static org.springframework.http.HttpHeaders.CONTENT_DISPOSITION;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.support.SessionStatus;
import org.springframework.web.servlet.ModelAndView;

/**
 *
 * @author jaspr_000
 */
@Controller
public class AdminController {

    @GetMapping("/adddpostcategory")
    public ModelAndView addPostCategory() {
        ModelAndView mav = new ModelAndView("categorycount");
        return mav;
    }

    @GetMapping("/addcategory*")
    public ModelAndView addPostCategoryPost(ModelMap model, HttpServletRequest request, PostCategory p_category, HttpServletResponse response) {      
        ModelAndView mav = new ModelAndView("createcategoryform", "p_category", p_category);       
        return mav;
    }

    @PostMapping("/addcategory*")
    public ModelAndView addCategoryPost(HttpServletRequest request, HttpServletResponse response,
            @Valid @ModelAttribute("p_category") PostCategory p_category, CategoryDao categorydao,
            PostCategory postcategory, BindingResult result, ModelMap model, SessionStatus status, SubscriptionDao subscriptionDao) {
        ModelAndView mav = new ModelAndView();
        String categoryadded = request.getParameter("categoryname");
        
        if (categorydao.categoryExist(categoryadded) == false) {
            result.rejectValue("categoryname", "error.category", "Category already exist");
            String errmessage = "Category Already Exist";
            mav = new ModelAndView("createcategoryform", "errmessage", errmessage);
        } else if (categoryadded.equals("")) {
            result.rejectValue("categoryname", "error.category", "Category Can not be null");
            String errmessage = "Category can not be null";
            mav = new ModelAndView("createcategoryform", "errmessage", errmessage);
        } else {
            if (result.hasErrors()) {
                //System.out.println("------------------------------" + result.getAllErrors() + "----------------------------------------");
                String reserrors = "Error Creating Category";
                mav = new ModelAndView("createcategoryform", "reserrors", reserrors);
            } else {
                PostCategory category = categorydao.addCategory(categoryadded);
                if (category == null) {
                    String msg = "Error creating category";
                    mav = new ModelAndView("createcategoryform", "message", msg);
                    return mav;
                } else {
                    String msg = "Category Created";
                    mav = new ModelAndView("createcategoryform", "message", msg);
                    return mav;
                }
                
            }
        }
        return mav;
    }

    @GetMapping("/adminrequests")
    public ModelAndView adminRequestList(ModelMap model, HttpServletRequest request, HttpServletResponse response, AdminDao admindao) {
        ArrayList<AdminRequests> all_adminrequest_list = admindao.getAllAdminRequests();
        model.addAttribute("admin_request_list", all_adminrequest_list);
        ModelAndView mav = new ModelAndView("adminrequestlist");
        return mav;
    }

    @GetMapping("/viewrequest")
    public ModelAndView viewRequestGet(ModelMap model, HttpSession session, HttpServletRequest request, HttpServletResponse response, AdminDao admindao) {
        ModelAndView mav = new ModelAndView();
        try {
            String request_id = request.getParameter("requestedid");
            int request_id_int = Integer.parseInt(request_id);
            AdminRequests adminrequestbyid = admindao.getRequestById(request_id_int);
            if (adminrequestbyid == null) {
                String errorMsg = "No Request To entertain!";
                mav = new ModelAndView("errorPage", "errorMsg", errorMsg);
            } else if (adminrequestbyid != null) {
                mav = new ModelAndView("viewrequest", "adminrequestbyid", adminrequestbyid);
            } else {
                String errorMsg = "Something went wrong";
                mav = new ModelAndView("errorPage", "errorMsg", errorMsg);
            }
            
        } catch (Exception e) {
            System.out.println("****************************************************************************************" + e.getMessage());
            String errorMsg = e.getMessage();
            mav = new ModelAndView("errorPage", "errorMsg", errorMsg);
        }
        return mav;
    }

    @PostMapping("/viewrequest")
    public ModelAndView viewRequestPost(ModelMap model, HttpSession session, HttpServletRequest request, HttpServletResponse response, AdminDao admindao) {
        ModelAndView mav = new ModelAndView();
        String approvalstatus = request.getParameter("decision");
        String request_id = request.getParameter("requestedid");
        int request_id_int = Integer.parseInt(request_id);
        AdminRequests adminrequestbyid = admindao.getRequestById(request_id_int);

        if (approvalstatus != null) {
            String approvalstaus_msg = admindao.updateApprrovalStatus(adminrequestbyid, approvalstatus);
            if (!approvalstaus_msg.equals("Admin Approval Updated")) {
                String errorMsg = approvalstaus_msg;
                mav = new ModelAndView("errorPage", "errorMsg", errorMsg);
            } else {
                ArrayList<AdminRequests> all_adminrequest_list = admindao.getAllAdminRequests();
                model.addAttribute("admin_request_list", all_adminrequest_list);
                mav = new ModelAndView("adminrequestlist");
            }
            
        }
        return mav;
    }

    @GetMapping("/downloadbook")
    public ResponseEntity<byte[]> downloadBook(ModelMap model, HttpSession session, HttpServletRequest request, HttpServletResponse response, AdminDao admindao) throws IOException {
        String request_id = request.getParameter("requestedid");
        int request_id_int = Integer.parseInt(request_id);
        AdminRequests adminrequestbyid = admindao.getRequestById(request_id_int);

        String dirPath = "C:\\Users\\jaspr_000\\Desktop\\Temp";
        try {
            String fileName = adminrequestbyid.getBook().getFilename();
            return ResponseEntity.ok()
                    .contentType(MediaType.APPLICATION_OCTET_STREAM)
                    .header("Content-Disposition", "attachment; filename=\"" + fileName + "\"")
                    .body(adminrequestbyid.getBook().getFiledata());
        } catch (Exception e) {
            response.sendRedirect("errors.htm");
            return null;
        }
    }

    @GetMapping("/contest/createcontestform")
    public ModelAndView createContestGet(ModelMap model, HttpSession session, HttpServletRequest request, Contest c_contest,
            HttpServletResponse response, AdminDao admindao) {
        ModelAndView mav = new ModelAndView();
        try {
            mav = new ModelAndView("createcontestform", "c_contest", c_contest);
            return mav;
        } catch (Exception e) {
            String errorMsg = e.getMessage();
            mav = new ModelAndView("errorPage", "errorMsg", errorMsg);
            return mav;
        }
    }

    @PostMapping("/contest/createcontestform")
    public ModelAndView createContestPost(ModelMap model, HttpSession session, HttpServletRequest request,
            @Valid @ModelAttribute("c_contest") Contest c_contest,
            HttpServletResponse response, AdminDao admindao, BindingResult result, SessionStatus status) {
        ModelAndView mav = new ModelAndView();
        try {
            if (c_contest.getContestname().equals("")) {
                //result.rejectValue("contestname", "error.contestname", "Enter Contest Name");
                String errmessage = "Enter Contest Name";
                mav = new ModelAndView("createcontestform", "errmessage", errmessage);
                return mav;
            }
            if (c_contest.getDescription().equals("")) {
                //result.rejectValue("description", "error.description", "Enter description");
                String errmessage = "Enter description";
                mav = new ModelAndView("createcontestform", "errmessage", errmessage);
                return mav;
            }
            if (c_contest.getTopic().equals("")) {
                //result.rejectValue("topic", "error.topic", "Enter topic");
                String errmessage = "Enter topic";
                mav = new ModelAndView("createcontestform", "errmessage", errmessage);
                return mav;
            } else if (result.hasErrors()) {
                String errorMsg = "Error Creating Contest";
                mav = new ModelAndView("createcontestform", "errorMsg", errorMsg);
                return mav;
            } else {
                Contest contest = admindao.createContest(c_contest);
                if (contest == null) {
                    String errorMsg = "Something went wrong in creating contest";
                    mav = new ModelAndView("errorPage", "errorMsg", errorMsg);
                    return mav;
                } else {
                    mav = new ModelAndView("createcontestform", "succesmsg", "Contest Created Successfully");
                    return mav;
                }
            }
        } catch (Exception e) {
            String errorMsg = e.getMessage();
            mav = new ModelAndView("errorPage", "errorMsg", errorMsg);
            return mav;
        }
    }

    @GetMapping("/contest/adminseecontestslist")
    public ModelAndView AdminSeeContestList(ModelMap model, HttpSession session, HttpServletRequest request,
            HttpServletResponse response, AdminDao admindao, UserDao userdao) {
        ModelAndView mav = new ModelAndView();
        User user = (User) session.getAttribute("user");
        try {
            List<Contest> admin_see_contestlist = admindao.getAllContests();
            if (admin_see_contestlist == null) {
                String errorMsg = "No Contest Created Till Now!";
                mav = new ModelAndView("errorPage", "errorMsg", errorMsg);
                return mav;
            } else {
                mav = new ModelAndView("AdminViewContestList", "admin_see_contestlist", admin_see_contestlist);
                return mav;
            }
            
        } catch (Exception e) {
            String errorMsg = e.getMessage();
            mav = new ModelAndView("errorPage", "errorMsg", errorMsg);
            return mav;
        }
    }

    @GetMapping("/contest/adminviewcontest")
    public ModelAndView userViewContest(ModelMap model, HttpSession session, HttpServletRequest request,
            HttpServletResponse response, AdminDao admindao) {
        ModelAndView mav = new ModelAndView();
        try {
            int contest_id = Integer.parseInt(request.getParameter("contestid"));
            Contest contest = admindao.getContestById(contest_id);
            if (contest == null) {
                String errorMsg = "No Contest To SHOW!";
                mav = new ModelAndView("errorPage", "errorMsg", errorMsg);
                return mav;
            } else {
                if (contest.getWinner() != null) {
                    model.addAttribute("winner", contest.getWinner().getParticipant_user_id().getUsername());
                } 
                mav = new ModelAndView("AdminViewingContest", "contest", contest);
                return mav;
            }
           
        } catch (Exception e) {
            String errorMsg = e.getMessage();
            mav = new ModelAndView("errorPage", "errorMsg", errorMsg);
            return mav;
        }
    }

    @GetMapping("/contest/seeparticipantslist")
    public ModelAndView Admin_see_participant_list(ModelMap model, HttpSession session, HttpServletRequest request,
            HttpServletResponse response, AdminDao admindao) {
        ModelAndView mav = new ModelAndView();
        try {
            int contest_id = Integer.parseInt(request.getParameter("contestid"));
            Contest contest = admindao.getContestById(contest_id);
            ArrayList<Participants> contestpartcipantslist = (ArrayList<Participants>) admindao.getContestParticipants(contest);
            if (contestpartcipantslist == null) {
                String errorMsg = "No Particpants Yet";
                mav = new ModelAndView("errorPage", "errorMsg", errorMsg);
                return mav;
            } else {
                if (contest.getWinner() != null) {
                    model.addAttribute("participant", contest.getWinner().getParticipant_user_id().getUsername());
                } 
                mav = new ModelAndView("AdminSeePArticipants", "contestpartcipantslist", contestpartcipantslist);
                return mav;
            }
            
            
        } catch (Exception e) {
            String errorMsg = e.getMessage();
            mav = new ModelAndView("errorPage", "errorMsg", errorMsg);
            return mav;
        }
    }

    @GetMapping("/contest/viewparticipant")
    public ModelAndView AdminViewParticipant(ModelMap model, HttpSession session, HttpServletRequest request,
            HttpServletResponse response, AdminDao admindao, UserDao userdao) {
        ModelAndView mav = new ModelAndView();
        try {
            int participantid = Integer.parseInt(request.getParameter("participantid"));
            Participants participant = admindao.getParticipanyById(participantid);
            Contest contest = participant.getParticipant_contest();
            if (participant == null) {
                String errorMsg = "No Participant To Show!";
                mav = new ModelAndView("errorPage", "errorMsg", errorMsg);
                return mav;
            } else {
                if (contest.getWinner() != null) {
                    model.addAttribute("participant", contest.getWinner().getParticipant_user_id().getUsername());
                } 
                model.addAttribute("contest", contest);
                mav = new ModelAndView("AdminViewParticipant", "participant", participant);
                return mav;
            }
            
        } catch (Exception e) {
            String errorMsg = e.getMessage();
            mav = new ModelAndView("errorPage", "errorMsg", errorMsg);
            return mav;
        }
    }

    @GetMapping("/contest/declarewinner")
    public ModelAndView declareWinner(ModelMap model, HttpSession session, HttpServletRequest request,
            HttpServletResponse response, AdminDao admindao, UserDao userdao) {
        ModelAndView mav = new ModelAndView();
        try {
            int participantid = Integer.parseInt(request.getParameter("participantid"));
            Participants participant = admindao.getParticipanyById(participantid);
            Contest contest = participant.getParticipant_contest();
            if (participant == null) {
                String errorMsg = "No Participant To Show!";
                mav = new ModelAndView("errorPage", "errorMsg", errorMsg);
                return mav;
            } else {
                String msg = admindao.declareWinner(participant.getParticipant_contest(), participant);
                if (msg.equals("Winner Declared")) {
                    model.addAttribute("contestpartcipantslist", admindao.getContestParticipants(contest));
                    mav = new ModelAndView("AdminSeePArticipants", "winner", participant);
                    return mav;
                } else if (contest.getWinner() != null) {
                    model.addAttribute("contestpartcipantslist", admindao.getContestParticipants(contest));
                    mav = new ModelAndView("AdminSeePArticipants", "winner", participant);
                    return mav;
                } else {
                    model.addAttribute("contestpartcipantslist", admindao.getContestParticipants(contest));
                    mav = new ModelAndView("AdminSeePArticipants", "winner", participant);
                    return mav;
                }
                
            }
        } catch (Exception e) {
            String errorMsg = e.getMessage();
            mav = new ModelAndView("errorPage", "errorMsg", errorMsg);
            return mav;
        }
    }
    
//    private int getErrorCode(HttpServletRequest httpRequest) {
//        return (Integer) httpRequest
//                .getAttribute("javax.servlet.error.status_code");
//    }

}
