/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.buddingpoetry.controller;

import com.buddingpoetry.DAO.BookDao;
import com.buddingpoetry.pojo.User;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.servlet.ModelAndView;
import com.buddingpoetry.DAO.CartDao;
import com.buddingpoetry.DAO.SubscriptionDao;
import com.buddingpoetry.pojo.Book;
import com.buddingpoetry.pojo.CartOrder;
import com.buddingpoetry.pojo.Item;
import java.util.ArrayList;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PostMapping;

/**
 *
 * @author jaspr_000
 */
@Controller
public class CartController {

    @PostMapping("/cart/addtocart")
    public ModelAndView addToCarT(Model model, HttpSession session, HttpServletRequest request, CartDao cartdao, BookDao bookdao, SubscriptionDao subscriptionDao) {
        ModelAndView mav = new ModelAndView();
        
        try {
            
            User user = (User) session.getAttribute("user");
            String bookid = request.getParameter("itemid");
            Long book_id_long = Long.parseLong(bookid);

            String quantity = request.getParameter("quantity");
            int quantity_convert = Integer.parseInt(quantity);

            Book booktocart = bookdao.getBookByID(book_id_long);
            Item item = cartdao.addItemToCart(booktocart, user, quantity_convert);
            if (subscriptionDao.isUserSubscribed(user)) {
                model.addAttribute("subscribed", "yes");
            }
            if (item != null) {

                mav = new ModelAndView("viewcart", "user_item_list", cartdao.getUserItems(user));
                return mav;
            } else {
                String errorMsg = "Item Already Added To Cart";
                mav = new ModelAndView("errorPage", "errorMsg", errorMsg);
                return mav;
            }
            
        } catch (Exception e) {
            String errorMsg = e.getMessage();
            mav = new ModelAndView("errorPage", "errorMsg", errorMsg);
            return mav;
        }
    }

    @PostMapping("/cart/removeitem")
    public ModelAndView removeItemFromCart(Model model, HttpSession session, HttpServletRequest request, CartDao cartdao, BookDao bookdao, SubscriptionDao subscriptionDao) {
        ModelAndView mav = new ModelAndView();
        User user = (User) session.getAttribute("user");
        try {
            if (subscriptionDao.isUserSubscribed(user)) {
                model.addAttribute("subscribed", "yes");
            }
            
            String itemid = request.getParameter("itemid");
            int itemid_convert = Integer.parseInt(itemid);

            String quantity = request.getParameter("quantity");
            int quantity_convert = Integer.parseInt(quantity);

            Item item_to_be_removed = cartdao.getItemById(itemid_convert);
            
            System.out.println("111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111" + item_to_be_removed);
            if (item_to_be_removed != null) {
                Item removed_item = cartdao.removeItemFromCart(item_to_be_removed, user, quantity_convert);
                model.addAttribute("user_item_list", cartdao.getUserItems(user));
                mav = new ModelAndView("viewcart", "successremovemsg", "Item removed");
                return mav;
            } else if (item_to_be_removed == null) {
                String errorMsg = "No Items to remove";
                mav = new ModelAndView("errorPage", "errorMsg", errorMsg);
                return mav;
            } else {
                String errorMsg = "Something went wrong";
                mav = new ModelAndView("errorPage", "errorMsg", errorMsg);
                return mav;
            }
            
        } catch (Exception e) {
            String errorMsg = e.getMessage();
            mav = new ModelAndView("errorPage", "errorMsg", errorMsg);
            return mav;
        }
    }

    @GetMapping("/book/cart")
    public ModelAndView getCart(Model model,HttpSession session, HttpServletRequest request, CartDao cartdao, BookDao bookdao, SubscriptionDao subscriptionDao) {
        ModelAndView mav = new ModelAndView();
        User user = (User) session.getAttribute("user");
        try {
            if (subscriptionDao.isUserSubscribed(user)) {
                model.addAttribute("subscribed", "yes");
            }           
            mav = new ModelAndView("viewcart", "user_item_list", cartdao.getUserItems(user));
            return mav;
        } catch (Exception e) {
            String errorMsg = e.getMessage();
            mav = new ModelAndView("errorPage", "errorMsg", errorMsg);
            return mav;
        }
    }

    @GetMapping("/cart/checkout")
    public ModelAndView checkoutCart(Model model, HttpSession session, HttpServletRequest request, CartDao cartdao, BookDao bookdao, SubscriptionDao subscriptionDao) {
        ModelAndView mav = new ModelAndView();
        try {
            User user = (User) session.getAttribute("user");
            CartOrder order = cartdao.createCartOrder((ArrayList<Item>) cartdao.getUserItems(user), user);
            System.out.println("MSGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGG" + order);
            if (subscriptionDao.isUserSubscribed(user)) {
                model.addAttribute("subscribed", "yes");
            }  
            if (order == null) {
                String errorMsg = "NO ORDER TO CHECOUT";
                mav = new ModelAndView("errorPage", "errorMsg", errorMsg);
                return mav;

            } else {
                System.out.println("HERE");
                model.addAttribute("order", order);
                mav = new ModelAndView("vieworder", "items", cartdao.getUserItems(user));
                return mav;
            }
            
        } catch (Exception e) {
            String errorMsg = e.getMessage();
            mav = new ModelAndView("errorPage", "errorMsg", errorMsg);
            return mav;
        }
    }

    @GetMapping("/cart/pay")
    public ModelAndView payOrder(Model model, HttpSession session, HttpServletRequest request, CartDao cartdao, BookDao bookdao, SubscriptionDao subscriptionDao) {
        ModelAndView mav = new ModelAndView();
        User user = (User) session.getAttribute("user");
        try {
            int orderid = Integer.parseInt(request.getParameter("orderid"));
            CartOrder order = cartdao.findOrderbyOrderId(orderid);
            if (subscriptionDao.isUserSubscribed(user)) {
                model.addAttribute("subscribed", "yes");
            }  
            if (cartdao.payOrder(order) == true) {
                cartdao.updateUserOrderCart(user);
                model.addAttribute("successpaymentmsg", "Payment succesfully Done");
                mav = new ModelAndView("vieworder");
                return mav;
            } else {
                String errorMsg = "Something Went Wrong";
                mav = new ModelAndView("errorPage", "errorMsg", errorMsg);
                return mav;
            }
            
            
        } catch (Exception e) {
            String errorMsg = e.getMessage();
            mav = new ModelAndView("errorPage", "errorMsg", errorMsg);
            return mav;
        }
    }
    
//    private int getErrorCode(HttpServletRequest httpRequest) {
//        return (Integer) httpRequest
//                .getAttribute("javax.servlet.error.status_code");
//    }

}
