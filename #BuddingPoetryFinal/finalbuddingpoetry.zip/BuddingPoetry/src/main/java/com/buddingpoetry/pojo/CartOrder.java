/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.buddingpoetry.pojo;

import java.util.ArrayList;
import java.util.List;
import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import org.hibernate.annotations.DynamicUpdate;
import org.hibernate.annotations.OptimisticLockType;
import org.hibernate.annotations.OptimisticLocking;

/**
 *
 * @author jaspr_000
 */
@Entity
@OptimisticLocking(type = OptimisticLockType.DIRTY)
@DynamicUpdate
public class CartOrder {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private int order_cart_id;
    
    @ManyToOne
    private User order_user;
    /***********************/
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "cartorder")
    private List<Item> items = new ArrayList<>();
    /***********************/
    
    private boolean isPaid;
    
    public CartOrder(){
        
    }

    public int getOrder_cart_id() {
        return order_cart_id;
    }

    public void setOrder_cart_id(int order_cart_id) {
        this.order_cart_id = order_cart_id;
    }

    public List<Item> getItems() {
        return items;
    }

    public void setItems(List<Item> items) {
        this.items = items;
    }

    public User getOrder_user() {
        return order_user;
    }

    public void setOrder_user(User order_user) {
        this.order_user = order_user;
    }

    public boolean isIsPaid() {
        return isPaid;
    }

    public void setIsPaid(boolean isPaid) {
        this.isPaid = isPaid;
    }

}
