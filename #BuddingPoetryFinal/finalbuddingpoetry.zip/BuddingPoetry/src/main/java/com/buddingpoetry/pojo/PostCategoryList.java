/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.buddingpoetry.pojo;

import java.util.ArrayList;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

/**
 *
 * @author jaspr_000
 */
@Entity
public class PostCategoryList {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int categoryid;
    ArrayList<PostCategory> postcategorieslist = new ArrayList<>();

    public ArrayList<PostCategory> getPostcategorieslist() {
        return postcategorieslist;
    }

    public void setPostcategorieslist(ArrayList<PostCategory> postcategorieslist) {
        this.postcategorieslist = postcategorieslist;
    }

    public int getCategoryid() {
        return categoryid;
    }

    public void setCategoryid(int categoryid) {
        this.categoryid = categoryid;
    }
}
