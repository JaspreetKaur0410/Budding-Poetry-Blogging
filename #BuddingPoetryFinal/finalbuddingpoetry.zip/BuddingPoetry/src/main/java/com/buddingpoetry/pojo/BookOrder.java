/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.buddingpoetry.pojo;

import java.util.ArrayList;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

/**
 *
 * @author jaspr_000
 */
@Entity
@Table(name="book")
public class BookOrder {
    
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private String order_id;
    
    @OneToMany
    private ArrayList<Item> items_list;
    
    public BookOrder(){
        
    }

    public String getOrder_id() {
        return order_id;
    }

    public void setOrder_id(String order_id) {
        this.order_id = order_id;
    }

    public ArrayList<Item> getItems_list() {
        return items_list;
    }

    public void setItems_list(ArrayList<Item> items_list) {
        this.items_list = items_list;
    }

    @Override
    public String toString() {
        return "BookOrder{" + "items_list=" + items_list + '}';
    }
  
}
