/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.buddingpoetry.controller;

import com.buddingpoetry.DAO.CategoryDao;
import com.buddingpoetry.DAO.PostDao;
import com.buddingpoetry.DAO.SubscriptionDao;
import com.buddingpoetry.DAO.UserDao;
import com.buddingpoetry.pojo.Likes;
import com.buddingpoetry.pojo.Post;
import com.buddingpoetry.pojo.PostCategory;
import com.buddingpoetry.pojo.User;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.support.SessionStatus;
import org.springframework.web.servlet.ModelAndView;

/**
 *
 * @author jaspr_000
 */
@Controller
public class PostController {

    //------------------------------------------------------------ CREATE POST --------------------------------------------------------
    @PostMapping("/postcreated")
    public ModelAndView createNewPost(ModelMap model, HttpServletRequest request, HttpServletResponse response,
            @ModelAttribute("post") Post post, HttpSession session, PostDao postdao,
            PostCategory postcategory, CategoryDao categorydao, BindingResult result, SessionStatus status, SubscriptionDao subscriptiondao) throws IOException {
        ModelAndView mav = new ModelAndView();
        ArrayList<String> errors = new ArrayList<>();

        String posttitle = request.getParameter("title");
        String[] categories = request.getParameterValues("category");
        String postcontent = request.getParameter("content");
        Date createddate = java.util.Calendar.getInstance().getTime();

        User user = (User) session.getAttribute("user");

        if (posttitle.equals("")) {
            String titleerrmsg = "Post not created,Post Title can't be null";
            errors.add(titleerrmsg);
            mav = new ModelAndView("postcreatederrors", "errors", errors);
            return mav;
        }
        if (categories == null) {
            String caterrmsg = "Post not created,Categories can't be null";
            errors.add(caterrmsg);
            mav = new ModelAndView("postcreatederrors", "errors", errors);
            return mav;
        }
        if (postcontent.equals("")) {
            String contenterrmsg = "Post not created,Post Title was not provided";
            errors.add(contenterrmsg);
            mav = new ModelAndView("postcreatederrors", "errors", errors);
            return mav;
        }
        if (posttitle.length() < 8) {
            String contenterrmsg = "Post not created,Post Topic length less than 8";
            errors.add(contenterrmsg);
            mav = new ModelAndView("postcreatederrors", "errors", errors);
            return mav;
        }
        if (postcontent.length() < 20) {
            String contenterrmsg = "Post not created,Content Should be atleast 20 characters";
            errors.add(contenterrmsg);
            mav = new ModelAndView("postcreatederrors", "errors", errors);
            return mav;
        } else if (result.hasErrors()) {
            mav = new ModelAndView("index");
            return mav;
        } else {
            if (subscriptiondao.isUserSubscribed(user)) {
                model.addAttribute("subscribed", "yes");
            }
            String create_post_msg = postdao.createPost(posttitle, postcontent, createddate, user, categories, categorydao);
            if (create_post_msg.equals("Post Created")) {
                model.addAttribute("categories", categorydao.getCategoryList());
                model.addAttribute("post", post);
                status.setComplete();
                String message = "Post Created";
                mav = new ModelAndView("index", "message", message);
                response.sendRedirect("index.htm");
                return mav;
            } else {
                String errorMsg = create_post_msg;
                mav = new ModelAndView("errorPage", "errorMsg", errorMsg);
                return mav;
            }

        }
    }

    //------------------------------------------------------------ CREATE POST --------------------------------------------------------
    @GetMapping("/index**")
    public ModelAndView loginProcessGetIndex(ModelMap model, HttpServletRequest request, UserDao userdao, PostDao postdao,
            HttpSession session, CategoryDao categorydao, SubscriptionDao subscriptiondao) {
        ModelAndView mav = new ModelAndView();
        User user = (User) session.getAttribute("user");
        try {
            ArrayList<Post> postslist = postdao.getPostList();
            HashMap<User, Post> user_post_map = new HashMap<>();

            if (postslist == null) {
                mav = new ModelAndView("index");
                return mav;
            } else {
                if (subscriptiondao.isUserSubscribed(user)) {
                    model.addAttribute("subscribed", "yes");
                }
                model.addAttribute("categories", categorydao.getCategoryList());
                model.addAttribute("posts", postslist);
                mav = new ModelAndView("index");
                return mav;
            }

        } catch (NumberFormatException e) {
            String errorMsg = e.getMessage();
            mav = new ModelAndView("errorPage", "errorMsg", errorMsg);
            return mav;
        }

    }

    @GetMapping("/deletepost")
    public ModelAndView deletePost(ModelMap model, HttpServletRequest request, HttpServletResponse response, UserDao userdao, PostDao postdao,
            HttpSession session, CategoryDao categorydao, SubscriptionDao subscriptiondao) throws IOException {

        ModelAndView mav = new ModelAndView();
        User user = (User) session.getAttribute("user");
        try {
            String postid = request.getParameter("postid");
            Post delpost = postdao.deletePost(Integer.parseInt(postid));

            if (delpost != null) {
                if (subscriptiondao.isUserSubscribed(user)) {
                    model.addAttribute("subscribed", "yes");
                }
                String message = "Post Deleted";
                mav = new ModelAndView("index", "message", message);
                response.sendRedirect("index.htm");
                return mav;
            } else {
                if (subscriptiondao.isUserSubscribed(user)) {
                    model.addAttribute("subscribed", "yes");
                }
                String errmsg = "Error Deleting post";
                mav = new ModelAndView("errorPage", "errMsg", errmsg);
                return mav;
            }

        } catch (IOException | NumberFormatException e) {
            String errorMsg = e.getMessage();
            mav = new ModelAndView("errorPage", "errorMsg", errorMsg);
            return mav;
        }
    }

    @GetMapping("/updatepost")
    public ModelAndView updatePost(ModelMap model, HttpServletRequest request, HttpServletResponse response, UserDao userdao, PostDao postdao,
            HttpSession session, CategoryDao categorydao, SubscriptionDao subscriptiondao) throws IOException {

        ModelAndView mav = new ModelAndView();
        User user = (User) session.getAttribute("user");
        try {
            String postid = request.getParameter("postid");
            Post post = postdao.getPostById(Integer.parseInt(postid));
            if (subscriptiondao.isUserSubscribed(user)) {
                model.addAttribute("subscribed", "yes");
            }
            if (post == null) {
                String errmsg = "Error Updating post";
                mav = new ModelAndView("errorPage", "errMsg", errmsg);
                return mav;
            } else  {
                model.addAttribute("categories", categorydao.getCategoryList());
                model.addAttribute("res_pos", post);
                mav = new ModelAndView("updatepost");
                return mav;
            }

        } catch (NumberFormatException e) {
            String errorMsg = e.getMessage();
            mav = new ModelAndView("errorPage", "errorMsg", errorMsg);
            return mav;
        }
    }

    @PostMapping("/updatepostprocessing")
    public ModelAndView updatePostPost(ModelMap model, HttpServletRequest request, HttpServletResponse response, UserDao userdao, PostDao postdao,
            HttpSession session, CategoryDao categorydao, BindingResult result, SessionStatus status, SubscriptionDao subscriptiondao) throws IOException {
        ModelAndView mav = new ModelAndView();
        User user = (User) session.getAttribute("user");
        try {
            if (subscriptiondao.isUserSubscribed(user)) {
                model.addAttribute("subscribed", "yes");
            }
            String posttitle = request.getParameter("title");
            String[] categories = request.getParameterValues("category");
            String postcontent = request.getParameter("content");
            Date createddate = java.util.Calendar.getInstance().getTime();

            String postid = request.getParameter("postid");
            Post post = postdao.getPostById(Integer.parseInt(postid));

            String update_post_msg = postdao.updatePost(posttitle, categories, postcontent, createddate, post, (User) session.getAttribute("user"), categorydao);
            if (update_post_msg.equals("post updated")) {
                model.addAttribute("categories", categorydao.getCategoryList());
                status.setComplete();
                String message = update_post_msg;
                mav = new ModelAndView("index", "message", message);
                response.sendRedirect("index.htm");
                return mav;
            } else {
                String errorMsg = update_post_msg;
                mav = new ModelAndView("errorPage", "errorMsg", errorMsg);
                return mav;
            }
        } catch (NumberFormatException e) {
            String errorMsg = e.getMessage();
            mav = new ModelAndView("errorPage", "errorMsg", errorMsg);
            return mav;
        }

    }

    @GetMapping("/likepost")
    public ModelAndView likePost(ModelMap model, HttpServletRequest request, HttpServletResponse response, UserDao userdao, PostDao postdao,
            HttpSession session, BindingResult result, SessionStatus status, SubscriptionDao subscriptiondao) throws IOException {

        ModelAndView mav = new ModelAndView();
        User user = (User) session.getAttribute("user");
        try {
            if (subscriptiondao.isUserSubscribed(user)) {
                model.addAttribute("subscribed", "yes");
            }
            String postid = request.getParameter("postid");
            Post post = postdao.getPostById(Integer.parseInt(postid));
            
            if (post == null) {
                String errorMsg = "NO POST TO LIKE";
                mav = new ModelAndView("errorPage", "errorMsg", errorMsg);
                return mav;
            } else {
                if (result.hasErrors()) {
                    String errors = "Error! Post not Liked";
                    mav = new ModelAndView("errorPage", "errorMsg", errors);
                    return mav;
                } else if (!result.hasErrors()) {
                    System.out.println("mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm" + "NOT LIKED");
                    Likes likebyuseronpost = postdao.likePost(post, (User) session.getAttribute("user"));
                    if (likebyuseronpost == null) {
                        String errorMsg = "ERROR LIKING POST";
                        mav = new ModelAndView("errorPage", "errorMsg", errorMsg);
                        return mav;
                    } else {
                        String message = "Post Liked";
                        mav = new ModelAndView("index", "message", message);
                        response.sendRedirect("index.htm");
                        return mav;
                    }
                }
            }
        } catch (NumberFormatException e) {
            String errorMsg = e.getMessage();
            mav = new ModelAndView("errorPage", "errorMsg", errorMsg);
            return mav;
        }
        return mav;
    }

    @GetMapping("/search/post")
    public ModelAndView searchByWriter(Model model, HttpServletRequest request, PostDao postdao, SubscriptionDao subscriptionDao, HttpSession session) {

        ModelAndView mav = new ModelAndView();
        User user = (User) session.getAttribute("user");
        
        try {
            if (subscriptionDao.isUserSubscribed(user)) {
                model.addAttribute("subscribed", "yes");
            }
            String keyword = request.getParameter("searchbywriter");
            List<Post> postbywriters_list = postdao.searchPostByWriter(keyword);
            model.addAttribute("postbywriters_list", postbywriters_list);
            mav = new ModelAndView("index");
            return mav;
        } catch (NumberFormatException e) {
            String errorMsg = e.getMessage();
            mav = new ModelAndView("errorPage", "errorMsg", errorMsg);
            return mav;
        }
    }

    @GetMapping("/search/searchbycategory")
    public ModelAndView searchByCategory(Model model, HttpServletRequest request, PostDao postdao, CategoryDao categorydao) {

        ModelAndView mav = new ModelAndView();
        try {
            String keyword = request.getParameter("searchbycategory");
            List<Post> postbywriters_list = postdao.searchPostByCategory(keyword, categorydao);
            model.addAttribute("postbywriters_list", postbywriters_list);
            mav = new ModelAndView("index");
            return mav;
        } catch (NumberFormatException e) {
            String errorMsg = e.getMessage();
            mav = new ModelAndView("errorPage", "errorMsg", errorMsg);
            return mav;
        }
    }

//    private int getErrorCode(HttpServletRequest httpRequest) {
//        return (Integer) httpRequest
//                .getAttribute("javax.servlet.error.status_code");
//    }
}
