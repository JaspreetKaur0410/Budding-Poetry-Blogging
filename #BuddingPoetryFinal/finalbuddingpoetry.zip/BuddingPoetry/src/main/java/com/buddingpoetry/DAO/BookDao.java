/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.buddingpoetry.DAO;

import com.buddingpoetry.pojo.AdminRequests;
import com.buddingpoetry.pojo.Book;
import com.buddingpoetry.pojo.User;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import javax.servlet.http.HttpSession;
import org.apache.commons.io.IOUtils;
import org.hibernate.Criteria;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.web.multipart.MultipartFile;

/**
 *
 * @author jaspr_000
 */
@Repository
public class BookDao extends DAO {

    public Book addBook(HttpSession session, String book_title, String book_category, String summary, byte[] filedata, String filename, UserDao userdao) {
        User user = (User) session.getAttribute("user");
        ArrayList<User> user_list = userdao.getAllUsers();
        try {
            for (User admin_user : (ArrayList<User>) user_list) {
                if (String.valueOf(admin_user.getRole()).equals(String.valueOf("admin"))) {
                    Book book = new Book();
                    if (!isBookExist(book_title)) {
                        book.setBook_title(book_title);
                        book.setBook_category(book_category);
                        book.setSummary(summary);
                        book.setAuthor_id(user.getId());
                        book.setApprovedtosell(false);
                        book.setFiledata(filedata);
                        book.setFilename(filename);
                        begin();
                        getSession().save(book);
                        commit();
                        return book;
                    } else {
                        return null;
                    }
                }
            }
        } catch (Exception e) {
            return null;
        }
        return null;
    }

    public String sendRequestToAdmin(HttpSession session, Book book, UserDao userdao) {
        User current_user = (User) session.getAttribute("user");
        ArrayList<User> user_list = userdao.getAllUsers();
        System.out.println("++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" + user_list);
        for (User user : (ArrayList<User>) user_list) {
            if (!String.valueOf(user.getRole()).equals(String.valueOf("admin"))) {
                continue;
            }
            try {
                List<AdminRequests> admin_request_list = user.getAdmin_request_list();
                AdminRequests adminrequest = new AdminRequests();
                adminrequest.setAdmin_user_requestedby(current_user);
                adminrequest.setApprovalstatus("pending");
                adminrequest.setBook(book);
                admin_request_list.add(adminrequest);
                user.setAdmin_request_list(admin_request_list);
                begin();
                getSession().save(adminrequest);
                commit();
                return "Request Sent";

            } catch (Exception e) {
                return "Something Went Wrong";
            }
        }
        return "Something Went Wrong";
    }

    public ArrayList<Book> getAllBooks() {
        ArrayList<Book> books_list = new ArrayList<>();
        begin();
        Criteria criteria = getSession().createCriteria(Book.class);
        books_list = (ArrayList<Book>) criteria.list();
        commit();
        return books_list;
    }

    public Boolean isBookExist(String book_title) {
        for (Book b : getAllBooks()) {
            if (String.valueOf(b.getBook_title()).equals(String.valueOf(book_title))) {
                return true;
            }
        }
        return false;
    }

    public ArrayList<Book> getBuyBook_List(AdminDao admindao) {
        ArrayList<Book> bookstosell_list = new ArrayList<>();
        for (Book b : getAllBooks()) {
            for (AdminRequests ar : admindao.getAllAdminRequests()) {
                if (String.valueOf(b.getBookid()).equals(String.valueOf(ar.getBook().getBookid()))) {
                    if (String.valueOf(ar.getApprovalstatus()).equals("approved")) {
                        if(!bookstosell_list.contains(b))
                            bookstosell_list.add(b);
                    }
                }
            }
        }

        return bookstosell_list;
    }

    public Book getBookByID(Long bookid) {
        try {
            Criteria crit = getSession().createCriteria(Book.class);
            crit.add(Restrictions.eq("bookid", bookid));
            Book book = (Book) crit.uniqueResult();
            return book;
        } catch (Exception e) {
            return null;
        }
    }

}
