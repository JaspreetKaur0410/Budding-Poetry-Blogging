/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.buddingpoetry.DAO;

import com.buddingpoetry.pojo.Post;
import com.buddingpoetry.pojo.PostCategory;
import com.buddingpoetry.pojo.User;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale.Category;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import org.hibernate.Criteria;
import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.criterion.Restrictions;

/**
 *
 * @author jaspr_000
 */
public class CategoryDao extends DAO {

    public ArrayList<PostCategory> getCategoryList() {

        ArrayList<PostCategory> categories = new ArrayList<>();
        Session session = getSession();
        Transaction t = session.beginTransaction();
        Criteria criteria = session.createCriteria(PostCategory.class);
        categories = (ArrayList<PostCategory>) criteria.list();
        t.commit();
        return categories;
    }

    public ArrayList<Post> getPostList() {

        ArrayList<Post> posts = new ArrayList<>();
        Session session = getSession();
        Transaction t = session.beginTransaction();
        Criteria criteria = session.createCriteria(Post.class);
        posts = (ArrayList<Post>) criteria.list();
        t.commit();
        return posts;
    }

    public PostCategory addCategory(String categoryName) {

        PostCategory category = new PostCategory();

        try {
            category.setCategoryname(categoryName);
            Session session = getSession();
            Transaction t = session.beginTransaction();
            session.save(category);
            t.commit();
            return category;

        } catch (HibernateException e) {

            e.printStackTrace();
            rollback();

            return null;

        } finally {

            close();

        }
    }

    public boolean categoryExist(String category) {

        Criteria criteria = getSession().createCriteria(PostCategory.class);
        criteria.add(Restrictions.eq("categoryname", category));
        PostCategory postcategory = (PostCategory) criteria.uniqueResult();
        if (postcategory != null) {
            return false;
        } else {
            return true;
        }

    }

    public boolean isCategoryVaid(String categorytocheck) {
        for(PostCategory c:getCategoryList()){
            if(String.valueOf(c.getCategoryname()).equals(categorytocheck)){
                return true;
            }
        }
        return false;
    }

}
