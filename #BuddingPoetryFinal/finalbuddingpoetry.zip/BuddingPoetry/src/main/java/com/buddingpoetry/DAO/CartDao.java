/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.buddingpoetry.DAO;

import com.buddingpoetry.pojo.Book;
import com.buddingpoetry.pojo.CartOrder;
import com.buddingpoetry.pojo.Item;

import com.buddingpoetry.pojo.User;
import com.google.protobuf.StringValue;
import com.razorpay.Order;
import java.util.ArrayList;
import java.util.List;
import javax.persistence.Query;
import org.hibernate.Criteria;
import org.hibernate.HibernateException;
import org.hibernate.ScrollableResults;
import org.hibernate.criterion.Restrictions;

/**
 *
 * @author jaspr_000
 */
public class CartDao extends DAO {

    public Item addItemToCart(Book booktocart, User user, int quantity_convert) {
      
        try {
            if (getUserItems(user).isEmpty()) {
                int cost = 20 * quantity_convert;
                Item item = new Item();
                item.setBuy_user_item(user);
                item.setItem_book(booktocart);
                item.setQuantity(quantity_convert);
                item.setCost(cost);
                getUserItems(user).add(item);
                user.setUser_items(getUserItems(user));
                begin();
                getSession().save(item);
                commit();
                return item;
            } else if (!getUserItems(user).isEmpty()) {

                for (Item i : getUserItems(user)) {

                    if (!String.valueOf(i.getItem_book().getBookid()).equals(String.valueOf(booktocart.getBookid()))) {
                        int cost = 20 * quantity_convert;
                        Item item = new Item();
                        item.setBuy_user_item(user);
                        item.setItem_book(booktocart);
                        item.setQuantity(quantity_convert);
                        item.setCost(cost);
                        getUserItems(user).add(item);
                        user.setUser_items(getUserItems(user));
                        begin();
                        getSession().save(item);
                        commit();
                        return item;
                    } else {

                        return null;
                    }
                }
            }
        } catch (Exception e) {
            System.out.println("zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz");
            String ex = e.getMessage();
            return null;
        }
        return null;
    }

    public Item removeItemFromCart(Item item1, User user, int quantity_convert) {
        int update_quantity;
        for (Item i : getUserItems(user)) {
            //if (String.valueOf(i.getBuy_user_item().getId()).equals(user.getId())) {
            if (String.valueOf(i.getId()).equals(String.valueOf(item1.getId()))) {
                if (quantity_convert > 1 && i.getCost() > 0) {
                    quantity_convert = quantity_convert - 1;
                    begin();
                    i.setCost((i.getCost()) - 20);
                    i.setQuantity(quantity_convert);
                    getSession().update(i);
                    commit();
                    return i;
                } else if (quantity_convert == 1) {
                    begin();
                    System.out.println("101001010100101001111111111111111111111111111111111111111111111111111111111111111111111111111111" + i + " " + quantity_convert);
                    getSession().delete(i);
                    commit();
                    return i;
                }
                System.out.println("iiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiii" + quantity_convert);
            }

            //}
        }
        return null;
    }

    public List<Item> getItemListofUser() {
        List<Item> items = new ArrayList<>();
        begin();
        Criteria criteria = getSession().createCriteria(Item.class);
        items = criteria.list();
        commit();
        return items;
    }

    public Item getItemById(int itemid_convert) {
        try {
            Criteria crit = getSession().createCriteria(Item.class);
            crit.add(Restrictions.eq("id", itemid_convert));
            Item removed_item = (Item) crit.uniqueResult();
            return removed_item;
        } catch (HibernateException e) {
            System.out.println("EXCEPTIOnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnn" + e.getMessage());
            return null;
        }
    }

    public List<Item> getUserItems(User user) {
        List<Item> items = new ArrayList<>();
        begin();
        Criteria criteria = getSession().createCriteria(Item.class);
        criteria.createAlias("buy_user_item", "bui");
        criteria.add(Restrictions.eq("bui.id", user.getId()));
        items = criteria.list();
        commit();
        return items;
    }

    public CartOrder createCartOrder(ArrayList<Item> items, User user) {
        try {
            CartOrder ordercart = new CartOrder();
            ordercart.setItems(items);
            ordercart.setOrder_user(user);
            ordercart.setIsPaid(false);
            user.getCartorders().add(ordercart);
            for (Item i : items) {
                System.out.println("HELOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOO");
                i.setCartorder(ordercart);
            }
            begin();
            getSession().save(ordercart);
            commit();
            System.out.println("+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" + ordercart.getItems());
            return ordercart;
        } catch (Exception e) {
            return null;
        }
    }

    public boolean payOrder(CartOrder order) {
        try {
            order.setIsPaid(true);
            begin();
            getSession().update(order);
            commit();
            return true;
        } catch (Exception e) {
            System.out.println("gggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggg" + e.getMessage());
            return false;
        }
    }

    public CartOrder findOrderbyOrderId(int orderid) {
        begin();
        Criteria criteria = getSession().createCriteria(CartOrder.class);
        criteria.add(Restrictions.eq("order_cart_id", orderid));
        CartOrder order = (CartOrder) criteria.uniqueResult();
        commit();
        return order;
    }

    public void updateUserOrderCart(User user) {
        try {
            for (Item i : getUserItems(user)) {
                begin();
                //System.out.println("101001010100101001111111111111111111111111111111111111111111111111111111111111111111111111111111" + i + " " + quantity_convert);
                getSession().delete(i);
                commit();
            }
        } catch (Exception e) {
            System.out.println("gggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggg" + e.getMessage());
        }
    }

}
