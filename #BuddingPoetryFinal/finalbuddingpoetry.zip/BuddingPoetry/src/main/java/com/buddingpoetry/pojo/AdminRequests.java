/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.buddingpoetry.pojo;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;

/**
 *
 * @author jaspr_000
 */
@Entity
@Table(name = "admin_requests")
public class AdminRequests {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int admin_request_id;
    
    @ManyToOne
    @JoinColumn(name="user_id")
    private User admin_user_requestedby;
    
    private String approvalstatus;
    
    @OneToOne
    private Book book;
    
    public AdminRequests(){
        
    }

    public int getAdmin_request_id() {
        return admin_request_id;
    }

    public void setAdmin_request_id(int admin_request_id) {
        this.admin_request_id = admin_request_id;
    }

    public User getAdmin_user_requestedby() {
        return admin_user_requestedby;
    }

    public void setAdmin_user_requestedby(User admin_user_requestedby) {
        this.admin_user_requestedby = admin_user_requestedby;
    }

    public String getApprovalstatus() {
        return approvalstatus;
    }

    public void setApprovalstatus(String approvalstatus) {
        this.approvalstatus = approvalstatus;
    }

    public Book getBook() {
        return book;
    }

    public void setBook(Book book) {
        this.book = book;
    }

    @Override
    public String toString() {
        return admin_user_requestedby.getUsername();
    }

}
