/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.buddingpoetry.pojo;

import java.util.Date;
import java.util.List;
import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;
import org.hibernate.annotations.DynamicUpdate;

/**
 *
 * @author jaspr_000
 */
@Entity
@Table(name = "subscription")
@DynamicUpdate
public class UserSubscription {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long subscriptionid;
    private String orderid;
    private int amount;
    private String receipt;
    private String status;

    @Transient
    private int userid;

    @Temporal(TemporalType.DATE)
    private Date subscription_date;
////////////////////////////////////////////////////////////////////////////////////////
    @ManyToOne
    @JoinColumn(name="user_id")
    private User susbscribed_user;
///////////////////////////////////////////////////////////////////////////////////////
    private String paymentid;

    public UserSubscription() {

    }

    public Long getSubscriptionid() {
        return subscriptionid;
    }

    public void setSubscriptionid(Long subscriptionid) {
        this.subscriptionid = subscriptionid;
    }

    public String getOrderid() {
        return orderid;
    }

    public void setOrderid(String orderid) {
        this.orderid = orderid;
    }

    public int getAmount() {
        return amount;
    }

    public void setAmount(int amount) {
        this.amount = amount;
    }

    public String getReceipt() {
        return receipt;
    }

    public void setReceipt(String receipt) {
        this.receipt = receipt;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    

    public Date getSubscription_date() {
        return subscription_date;
    }

    public void setSubscription_date(Date subscription_date) {
        this.subscription_date = subscription_date;
    }

    public String getPaymentid() {
        return paymentid;
    }

    public void setPaymentid(String paymentid) {
        this.paymentid = paymentid;
    }

    public int getUserid() {
        return userid;
    }

    public void setUserid(int userid) {
        this.userid = userid;
    }

    public User getSusbscribed_user() {
        return susbscribed_user;
    }

    public void setSusbscribed_user(User susbscribed_user) {
        this.susbscribed_user = susbscribed_user;
    }
    
    

    @Override
    public String toString() {
        return String.valueOf(subscriptionid);
    }

}
