/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.buddingpoetry.pojo;

import com.mysql.cj.jdbc.Blob;
import java.awt.Image;
import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Transient;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import org.springframework.web.multipart.MultipartFile;

/**
 *
 * @author jaspr_000
 */
@Entity
@Table(name="book")
public class Book {
    
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long bookid;
    
    @NotEmpty(message = "Please enter your Book Title!")
    private String book_title;
   
    private int author_id;
    
    @NotEmpty(message = "Please enter Book Category")
    private String book_category;
    
    @NotEmpty(message = "Please provide Book Summary")
    private String summary;
    
    private boolean approvedtosell;

    private String filename;
    
    @Transient
    private MultipartFile multipartFile;
    
    @Lob
    @NotEmpty(message = "Please upload file")
    private byte[] filedata;
    
    @OneToOne(mappedBy = "item_book", cascade = CascadeType.PERSIST)
    private Item book_item; 
    
    public Book(){
        
    }

    public Long getBookid() {
        return bookid;
    }

    public void setBookid(Long bookid) {
        this.bookid = bookid;
    }

    public String getBook_title() {
        return book_title;
    }

    public void setBook_title(String book_title) {
        this.book_title = book_title;
    }

    public int getAuthor_id() {
        return author_id;
    }

    public void setAuthor_id(int author_id) {
        this.author_id = author_id;
    }

    public String getBook_category() {
        return book_category;
    }

    public void setBook_category(String book_category) {
        this.book_category = book_category;
    }

    public String getSummary() {
        return summary;
    }

    public void setSummary(String summary) {
        this.summary = summary;
    }

    public boolean isApprovedtosell() {
        return approvedtosell;
    }

    public void setApprovedtosell(boolean approvedtosell) {
        this.approvedtosell = approvedtosell;
    }

    public String getFilename() {
        return filename;
    }

    public void setFilename(String filename) {
        this.filename = filename;
    }

    public byte[] getFiledata() {
        return filedata;
    }

    public void setFiledata(byte[] filedata) {
        this.filedata = filedata;
    }

    public MultipartFile getMultipartFile() {
        return multipartFile;
    }

    public void setMultipartFile(MultipartFile multipartFile) {
        this.multipartFile = multipartFile;
    }

    public Item getBook_item() {
        return book_item;
    }

    public void setBook_item(Item book_item) {
        this.book_item = book_item;
    }
    
 
    @Override
    public String toString() {
        return "Book{" + "book_title=" + book_title + '}';
    }

}
