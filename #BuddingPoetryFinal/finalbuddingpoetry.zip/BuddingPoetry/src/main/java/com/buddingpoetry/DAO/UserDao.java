/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.buddingpoetry.DAO;

import static com.buddingpoetry.DAO.DAO.getSession;
import com.buddingpoetry.pojo.Contest;
import com.buddingpoetry.pojo.Participants;
import com.buddingpoetry.pojo.Post;
import com.buddingpoetry.pojo.PostCategory;
import com.buddingpoetry.pojo.User;
import com.buddingpoetry.pojo.UserSubscription;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import javax.persistence.Query;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.JoinType;
import javax.persistence.criteria.Root;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.annotations.FetchMode;
import org.hibernate.criterion.CriteriaQuery;
import org.hibernate.criterion.CriteriaSpecification;
import org.hibernate.criterion.ProjectionList;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;

/**
 *
 * @author jaspr_000
 */
public class UserDao extends DAO {

    public String addUser(String username, String email, String password, String cnfrmpwd, String role) {
        try {
            User user = new User();
            user.setUsername(username);
            user.setEmail(email);
            user.setPassword(password);
            user.setRole(role);
            user.setCnfrmpwd(cnfrmpwd);
            //user.setSubscription(null);
            begin();
            getSession().save(user);
            commit();
            return "user added";
        } catch (Exception e) {
            return e.getMessage().toString();
        }

    }

    public ArrayList<User> getAllUsers() {
        ArrayList<User> users_list = new ArrayList<>();
        begin();
        Criteria criteria = getSession().createCriteria(User.class);
        users_list = (ArrayList<User>) criteria.list();
        commit();
        return users_list;
    }

    public boolean userExists(String useremail) {

        Criteria criteria = getSession().createCriteria(User.class);
        criteria.add(Restrictions.eq("email", useremail));
        User user = (User) criteria.uniqueResult();
        if (user != null) {
            return false;
        } else {
            return true;
        }

    }

    public User getUserByEmail(String useremail) {

        Criteria crit = getSession().createCriteria(User.class);
        crit.add(Restrictions.eq("email", useremail));
        User user = (User) crit.uniqueResult();
        return user;
    }

    public HashMap<User, Post> getUsers_Post(Post post) {

        HashMap<User, Post> user_post_map = new HashMap<>();

        Criteria crit = getSession().createCriteria(User.class);
        crit.add(Restrictions.eq("id", post.getUserid()));
        User user = (User) crit.uniqueResult();

        user_post_map.put(user, post);

        if (user_post_map == null) {
            return null;
        } else {
            return user_post_map;
        }

    }

    public User getUserById(int id) {
        begin();
        Criteria criteria = getSession().createCriteria(User.class);
        criteria.add(Restrictions.eq("id", id));
        User user = (User) criteria.uniqueResult();
        commit();
        return user;
    }

    public Participants participateinContest(Contest contest, User user, String yourpoetry) {
        try {
            Participants participant = new Participants();
            participant.setParticipant_user_id(user);
            participant.setParticipant_contest(contest);
            participant.setPoetry(yourpoetry);
            participant.setIsPartcipated(true);
            begin();
            getSession().save(participant);
            commit();
            return participant;
        } catch (Exception e) {
            return null;
        }
    }

    public List<Participants> getAllParticipants() {
        try {
            ArrayList<Participants> partcipant_list = new ArrayList<>();
            begin();
            Criteria criteria = getSession().createCriteria(Participants.class);
            partcipant_list = (ArrayList<Participants>) criteria.list();
            commit();
            return partcipant_list;
        } catch (Exception e) {
            return null;
        }
    }

    public boolean checkIfUserPartcipated(Contest contest, User user, AdminDao admindao) {

        for (Participants p : getAllParticipants()) {
            if (String.valueOf(p.getParticipant_user_id().getId()).equals(String.valueOf(user.getId()))) {
                if (String.valueOf(contest.getContest_id()).equals(String.valueOf(p.getParticipant_contest().getContest_id()))) {
                    return true;
                }
            }
        }
        return false;
    }
    
  

    /* public ArrayList<Object> getUsers_Post() {

        HashMap<User, Post> user_post_map = new HashMap<>();
        Session session = getSession();
        Transaction t = session.beginTransaction();
        Criteria criteria = getSession().createCriteria(User.class, "user_join");
        criteria.setProjection(Projections.projectionList().
                add(Projections.property("user_join.post_user")).
                add(Projections.property("user_join.postid")).
                add(Projections.property("user_join.postname")).
                add(Projections.property("user_join.content")));
     
        System.out.println("&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&"+criteria.list()+"^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^");
        

        t.commit();
        return null;
    }*/
 /*public void addAdmin(String username, String email, String password, String cnfrmpwd, String role) {
        User user = new User();
        user.setUsername(username);
        user.setEmail(email);
        user.setPassword(password);
        user.setRole("admin");
        user.setCnfrmpwd(cnfrmpwd);

        Session session = getSession();
        Transaction tx = session.beginTransaction();
        session.save(user);
        tx.commit();
    }*/

 /*public boolean checkIfUserSubscribed(User user) {
        
        try{
        String hql = "FROM com.buddingpoetry.pojo.UserSubscription AS us, com.buddingpoetry.pojo.User AS u"
                + " WHERE us.subscribed_user = :u.id";
        System.out.println("(((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((("+hql);
        Query query = getSession().createQuery(hql);
        List results = query.getResultList();
        System.out.println("&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&"+results);
        if(results != null){
            return true;
        }
       
        }
        catch(Exception e){
            
        }
        
        begin();
        Criteria criteria = getSession().createCriteria(UserSubscription.class);
        criteria.add(Restrictions.eq("subscribed_user", Integer.valueOf(user.getId())));
        UserSubscription us = (UserSubscription) criteria.uniqueResult();
        System.out.println("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!"+us);
        commit();
        
        
        return false;
    }*/
}
