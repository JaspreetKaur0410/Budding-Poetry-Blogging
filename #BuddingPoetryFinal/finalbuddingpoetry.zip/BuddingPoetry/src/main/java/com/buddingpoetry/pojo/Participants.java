/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.buddingpoetry.pojo;

import java.util.ArrayList;
import java.util.List;
import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import org.hibernate.annotations.ManyToAny;

/**
 *
 * @author jaspr_000
 */
@Entity
@Table(name="participant")
public class Participants {
    
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private int participant_id;
    
    private String poetry;
    
    @ManyToOne
    private Contest participant_contest;
    
    @OneToOne
    private User participant_user_id;
    
    private boolean isPartcipated;
    
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "winner")
    private List<Contest> contest_winner = new ArrayList<>();
    
    public Participants(){
        
    }

    public int getParticipant_id() {
        return participant_id;
    }

    public void setParticipant_id(int participant_id) {
        this.participant_id = participant_id;
    }

    public Contest getParticipant_contest() {
        return participant_contest;
    }

    public void setParticipant_contest(Contest participant_contest) {
        this.participant_contest = participant_contest;
    }

    public User getParticipant_user_id() {
        return participant_user_id;
    }

    public void setParticipant_user_id(User participant_user_id) {
        this.participant_user_id = participant_user_id;
    }

    public boolean isIsPartcipated() {
        return isPartcipated;
    }

    public void setIsPartcipated(boolean isPartcipated) {
        this.isPartcipated = isPartcipated;
    }

    public String getPoetry() {
        return poetry;
    }

    public void setPoetry(String poetry) {
        this.poetry = poetry;
    }
    
    
  
    @Override
    public String toString() {
        return "Participants{" + "participant_id=" + participant_id + ", participant_user_id=" + participant_user_id + '}';
    }
  
}
