/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.buddingpoetry.controller;

import Utils.CommonMail;
import com.buddingpoetry.DAO.AdminDao;
import com.buddingpoetry.DAO.CategoryDao;
import com.buddingpoetry.DAO.DAO;
import com.buddingpoetry.DAO.PostDao;
import com.buddingpoetry.DAO.SubscriptionDao;
import com.buddingpoetry.DAO.UserDao;
import com.buddingpoetry.pojo.Contest;
import com.buddingpoetry.pojo.Participants;
import com.buddingpoetry.pojo.Post;
import com.buddingpoetry.pojo.PostCategory;
import com.buddingpoetry.pojo.User;
import com.buddingpoetry.pojo.UserSubscription;
import java.util.ArrayList;
import java.util.Map;
import java.util.regex.Pattern;
import javax.ejb.PostActivate;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;
import org.json.JSONObject;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;

import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.support.SessionStatus;
import org.springframework.web.servlet.ModelAndView;
import com.razorpay.*;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.http.HttpServletResponse;
import javax.ws.rs.core.Response;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;

/**
 *
 * @author jaspr_000
 */
@Controller
public class UserController {

    private PasswordEncoder passwordEncoder = new BCryptPasswordEncoder(10);

    @RequestMapping(value = "/register", method = RequestMethod.GET)
    public String showForm(ModelMap model, User user) {
        model.addAttribute(user);
        return "signup";
    }

    /**
     * ************************************************ SIGNUP PROCESS
     * *************************************************************
     */
    @PostMapping("/register")
    private String signUp(HttpServletRequest request, UserDao userdao, @Valid @ModelAttribute("user") User user,
            BindingResult result, ModelMap model, SessionStatus status, HttpServletResponse response, AdminDao admindao) {

        String view = "signup";

        String useremail = request.getParameter("email");
        String userpwd = request.getParameter("password");
        String hashedPassword = passwordEncoder.encode(userpwd);
        String cnfrmpwd = request.getParameter("retypepassword");
        String username = request.getParameter("username");
        String role = request.getParameter("role");

        if (6 > user.getPassword().length() || 20 < user.getPassword().length()) {
            result.rejectValue("password", "user.password.length", "Password should have length between 6 and 20 characters");
        }

        Pattern pattern = Pattern.compile("^(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9])(?=.*?[#?!@$%^&*-]).{6,20}");
        if (!(pattern.matcher(user.getPassword()).matches())) {
            result.rejectValue("password", "user.password.invalid", "Password must contain atleast 1 digit, lowercase letter, uppercase letter, special character and no whitespace");
        }

        if (!String.valueOf(user.getPassword()).equals(String.valueOf(user.getCnfrmpwd()))) {
            result.rejectValue("", "user.cnfrmpwd.invalid", "Passwords Don't Match!");
        }
        if (userdao.userExists(useremail) == false) {
            System.out.println("###############################USER ALREADY EXIST###############################");
            result.rejectValue("email", "error.user", "User already exist");
            view = "signup";
        } else {
            if (result.hasErrors()) {
                view = "signup";
            } else {
                try {
                    if (String.valueOf(role).equals("admin")) {
                        if (admindao.isAdminExist(user, userdao)) {
                            result.rejectValue("", "error.user", "Admin Aready Exist");
                        } else {
                            String msg = userdao.addUser(username, useremail, hashedPassword, cnfrmpwd, role);
                            if (msg.equals("user added")) {
                                status.setComplete();
                                try {
                                    CommonMail.sendEmailMessage(useremail, "User Account Created", "Dear " + username + " Congratulations! Your account is created!");
                                    model.addAttribute("message", "Account Created, You can now Login");
                                    view = "signup";
                                } catch (Exception e) {
                                    String errorMsg = e.getMessage();
                                    model.addAttribute("errorMsg", errorMsg);
                                    view = "errorPage";
                                }

                            } else {
                                String errorMsg = msg;
                                model.addAttribute("errorMsg", errorMsg);
                                view = "errorPage";
                            }
                        }
                    } else {
                        String msg = userdao.addUser(username, useremail, hashedPassword, cnfrmpwd, role);
                        if (msg.equals("user added")) {
                            status.setComplete();
                            try {
                                CommonMail.sendEmailMessage(useremail, "User Account Created", "Dear " + username + " Congratulations! Your account is created!");
                                model.addAttribute("message", "Account Created, You can now Login");
                                view = "signup";
                            } catch (Exception e) {
                                String errorMsg = e.getMessage();
                                model.addAttribute("errorMsg", errorMsg);
                                view = "errorPage";
                            }

                        } else {
                            String errorMsg = msg;
                            model.addAttribute("errorMsg", errorMsg);
                            view = "errorPage";
                        }
                    }

                } catch (Exception e) {
                    String errorMsg = e.getMessage();
                    model.addAttribute("errorMsg", errorMsg);
                    view = "errorPage";
                }
            }

        }
        return view;
    }

    @GetMapping("/signin")
    public String showLoginForm(ModelMap model, User user
    ) {
        model.addAttribute(user);
        return "signin";
    }

    /**
     * ************************************************ LOGIN PROCESS *
     * *************************************************************
     */
    @PostMapping("/index")
    public ModelAndView loginProcessPost(ModelMap model, HttpServletRequest request,
            @ModelAttribute("post") Post post, PostDao postdao,
            UserDao userdao, HttpSession session,
            CategoryDao categorydao, SubscriptionDao subscriptiondao
    ) {

        ModelAndView mav;

        String useremail = request.getParameter("email");
        String userpwd = request.getParameter("password");

        User user = userdao.getUserByEmail(useremail);

        if (user == null) {
            String errmsg = "Please Enter Valid Email Address";
            mav = new ModelAndView("signin", "errmsg", errmsg);
        } else {
            if (!passwordEncoder.matches(userpwd, user.getPassword())) {
                String errmsg = "Please Enter Valid Password";
                mav = new ModelAndView("signin", "errmsg", errmsg);
            } else if (subscriptiondao.isUserSubscribed(user)) {
                model.addAttribute("subscribed", "yes");
            }
            session.setAttribute("user", user);
            model.addAttribute("categories", categorydao.getCategoryList());
            ArrayList<Post> postslist = postdao.getPostList();
            model.addAttribute("posts", postslist);
            mav = new ModelAndView("index");
        }
        return mav;
    }

    @GetMapping("/logout")
    public ModelAndView logoutGet(HttpSession session
    ) {
        if (session.getAttribute("user") != null) {
            session.invalidate();
            ModelAndView mav = new ModelAndView("signin");
            return mav;
        } else {
            return null;
        }
    }

    @GetMapping("/subscriptionform")
    public ModelAndView subscriptionFormGet(ModelMap model, HttpServletRequest request, UserSubscription userSubscription
    ) {
        model.addAttribute("subscriptionamount", 50);
        ModelAndView mav = new ModelAndView("subscriptonform");
        return mav;
    }

    @RequestMapping(value = "subscribe/createorder", method = RequestMethod.POST)
    @ResponseBody
    public String processCheckoutPost(@RequestBody String json, SubscriptionDao subscriptiondao,
            HttpSession session
    ) {
        JSONObject jsonObj = new JSONObject(json);
        //System.out.println("*****************************************ORDER************************************");
        System.out.println("**********************************************************" + jsonObj.getInt("amount") + "**************************************************");

        try {
            RazorpayClient client = new RazorpayClient("rzp_test_CpSq9oajzMTyc1", "YIz8RorhZwFk0lON1KVJdPJC");
            JSONObject jsonob_client = new JSONObject();
            jsonob_client.put("amount", jsonObj.getInt("amount") * 100);
            jsonob_client.put("currency", "INR");
            jsonob_client.put("receipt", "txn_23453");
            Order order = client.Orders.create(jsonob_client);
            System.out.println(order);

            String add_subscription_status = subscriptiondao.addOrder(order, session);
            switch (add_subscription_status) {
                case "Exception Occurred":
                    System.out.println("Exception Occurred");
                    break;
                case "error":
                    System.out.println("Error Occurred");
                    break;
                case "Order Created":
                    System.out.println("Order Created");
                    break;
                default:
                    System.out.println("Something went wrong");
                    break;
            }
            return order.toString();
        } catch (RazorpayException ex) {
            Logger.getLogger(UserController.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
    }

    @RequestMapping(value = "subscribe/upadetpayment", method = RequestMethod.POST)
    @ResponseBody
    public String updatePaymentOnServer(@RequestBody String update_payment_json, ModelMap model,
            SubscriptionDao subscriptiondao, HttpSession session,
            UserDao userdao, HttpServletResponse resposne
    ) {
        JSONObject jsonObj = new JSONObject(update_payment_json);
        UserSubscription user_subscription_order = subscriptiondao.getOrderById(session, jsonObj.get("order_id").toString());

        if (user_subscription_order != null) {
            user_subscription_order.setPaymentid(jsonObj.get("payment_id").toString());
            user_subscription_order.setStatus(jsonObj.get("status").toString());
            User user = (User) session.getAttribute("user");
            subscriptiondao.doPayment(user_subscription_order, user);
            try {
                CommonMail.sendEmailMessage(user.getEmail(), "User Account Subscribed", "Dear " + user.getUsername() + " Congratulations! Your account is subscribed!");
            } catch (Exception e) {
                String errorMsg = e.getMessage();
                System.out.println(errorMsg);
            }
            session.setAttribute("subscribed", "yes");
        }
        return "payment not done";
    }

    @GetMapping("/contest/userseecontest")
    public ModelAndView userSeeContestList(ModelMap model, HttpSession session,
            HttpServletRequest request,
            HttpServletResponse response,
            AdminDao admindao, UserDao userdao, SubscriptionDao subscriptiondao
    ) {
        ModelAndView mav = new ModelAndView();
        User user = (User) session.getAttribute("user");
        try {
            List<Contest> writer_see_contestlist = admindao.getAllContests();
            if (writer_see_contestlist == null) {
                String errorMsg = "No Contest Created Till Now!";
                mav = new ModelAndView("errorPage", "errorMsg", errorMsg);
                return mav;
            } else {
                if (subscriptiondao.isUserSubscribed(user)) {
                    model.addAttribute("subscribed", "yes");
                }
                mav = new ModelAndView("UserViewContest", "writer_see_contestlist", writer_see_contestlist);
                return mav;

            }
        } catch (Exception e) {
            String errorMsg = e.getMessage();
            mav = new ModelAndView("errorPage", "errorMsg", errorMsg);
            return mav;
        }
    }

    @GetMapping("/contest/viewcontest")
    public ModelAndView userViewContest(ModelMap model, HttpSession session,
            HttpServletRequest request,
            HttpServletResponse response,
            AdminDao admindao, SubscriptionDao subscriptiondao
    ) {
        ModelAndView mav = new ModelAndView();
        User user = (User) session.getAttribute("user");
        try {
            int contest_id = Integer.parseInt(request.getParameter("contestid"));
            Contest contest = admindao.getContestById(contest_id);
            if (contest == null) {
                String errorMsg = "No Contest To SHOW!";
                mav = new ModelAndView("errorPage", "errorMsg", errorMsg);
                return mav;
            } else {
                if (subscriptiondao.isUserSubscribed(user)) {
                    model.addAttribute("subscribed", "yes");
                }
                mav = new ModelAndView("viewcontestuser", "contest", contest);
                return mav;
            }

        } catch (Exception e) {
            String errorMsg = e.getMessage();
            mav = new ModelAndView("errorPage", "errorMsg", errorMsg);
            return mav;
        }
    }

    @GetMapping("/contest/participateform")
    public ModelAndView showarticipantForm(ModelMap model, HttpSession session,
            HttpServletRequest request,
            HttpServletResponse response,
            AdminDao admindao, UserDao userdao, SubscriptionDao subscriptiondao
    ) {
        ModelAndView mav = new ModelAndView();
        User user = (User) session.getAttribute("user");
        try {
            int contest_id = Integer.parseInt(request.getParameter("contestid"));
            Contest contest = admindao.getContestById(contest_id);

            if (contest == null) {
                String errorMsg = "No Contest To Participate!";
                mav = new ModelAndView("errorPage", "errorMsg", errorMsg);
                return mav;
            } else {
                if (subscriptiondao.isUserSubscribed(user)) {
                    model.addAttribute("subscribed", "yes");
                }
                if (!userdao.checkIfUserPartcipated(contest, user, admindao)) {
                    mav = new ModelAndView("partcipantform", "contest", contest);
                    return mav;
                } else {
                    model.addAttribute("alreadyparticipatederror", "THANKS FOR PARTICIPATING! WAIT FOR RESULTS");
                    mav = new ModelAndView("partcipantform", "contest", contest);
                    return mav;
                }

            }

        } catch (Exception e) {
            String errorMsg = e.getMessage();
            mav = new ModelAndView("errorPage", "errorMsg", errorMsg);
            return mav;
        }
    }

    @PostMapping("/contest/participate")
    public ModelAndView participateContest(ModelMap model, HttpSession session,
            HttpServletRequest request,
            HttpServletResponse response,
            AdminDao admindao, UserDao userdao, SubscriptionDao subscriptiondao
    ) {
        ModelAndView mav = new ModelAndView();
        User user = (User) session.getAttribute("user");
        try {
            String yourpoetry = request.getParameter("yourpoetry");
            int contest_id = Integer.parseInt(request.getParameter("contestid"));
            Contest contest = admindao.getContestById(contest_id);
            if (contest == null) {
                String errorMsg = "No Contest To Participate!";
                mav = new ModelAndView("errorPage", "errorMsg", errorMsg);
                return mav;
            } else if (yourpoetry == null) {
                String errorMsg = "Please write Your Poetry First";
                model.addAttribute("contestid", contest_id);
                model.addAttribute("contest", contest);
                mav = new ModelAndView("PoetryError", "errorMsg", errorMsg);
                return mav;
            } else {
                Participants participant = userdao.participateinContest(contest, user, yourpoetry);
                if (participant == null) {
                    model.addAttribute("particiant", participant);
                    String errorMsg = "Something Went Wrong in Participationg For COntest";
                    mav = new ModelAndView("errorPage", "errorMsg", errorMsg);
                    return mav;
                } else {
                    if (!userdao.checkIfUserPartcipated(contest, user, admindao)) {
                        mav = new ModelAndView("partcipantform", "succesparticipationg", "Thanks for Participating!");
                    } else {
                        if (subscriptiondao.isUserSubscribed(user)) {
                            model.addAttribute("subscribed", "yes");
                        }
                        model.addAttribute("alreadyparticipatederror", "THANKS FOR PARTICIPATING! WAIT FOR RESULTS");
                        mav = new ModelAndView("partcipantform", "contest", contest);
                        return mav;
                    }
                }
            }

        } catch (Exception e) {
            String errorMsg = e.getMessage();
            mav = new ModelAndView("errorPage", "errorMsg", errorMsg);
            return mav;
        }
        return mav;
    }

//    private int getErrorCode(HttpServletRequest httpRequest) {
//        return (Integer) httpRequest
//                .getAttribute("javax.servlet.error.status_code");
//    }
}
