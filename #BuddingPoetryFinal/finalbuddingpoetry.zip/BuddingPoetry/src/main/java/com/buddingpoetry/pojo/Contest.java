/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.buddingpoetry.pojo;

import java.util.ArrayList;
import java.util.List;
import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import org.hibernate.annotations.DynamicUpdate;
import org.hibernate.annotations.OptimisticLockType;
import org.hibernate.annotations.OptimisticLocking;

/**
 *
 * @author jaspr_000
 */
@Entity
@Table(name="contest")
@OptimisticLocking(type = OptimisticLockType.DIRTY)
@DynamicUpdate
public class Contest {
    
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private int contest_id;
    
    private String contestname;
    
    private String topic;
    
    private String description;
    
    //contest has many participants
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "participant_contest")
    private List<Participants> participants_list = new ArrayList<>();
    
    @OneToOne
    private Participants winner;
    
    public Contest(){
        
    }

    public int getContest_id() {
        return contest_id;
    }

    public void setContest_id(int contest_id) {
        this.contest_id = contest_id;
    }

    public String getContestname() {
        return contestname;
    }

    public void setContestname(String contestname) {
        this.contestname = contestname;
    }

    public String getTopic() {
        return topic;
    }

    public void setTopic(String topic) {
        this.topic = topic;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Participants getWinner() {
        return winner;
    }

    public void setWinner(Participants winner) {
        this.winner = winner;
    }

    public List<Participants> getParticipants_list() {
        return participants_list;
    }

    public void setParticipants_list(List<Participants> participants_list) {
        this.participants_list = participants_list;
    }

    @Override
    public String toString() {
        return contestname;
    }    
}
