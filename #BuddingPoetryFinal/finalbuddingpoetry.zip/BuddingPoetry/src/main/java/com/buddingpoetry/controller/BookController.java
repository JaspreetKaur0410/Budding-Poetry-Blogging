/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.buddingpoetry.controller;

import com.buddingpoetry.DAO.AdminDao;
import com.buddingpoetry.DAO.BookDao;
import com.buddingpoetry.DAO.SubscriptionDao;
import com.buddingpoetry.DAO.UserDao;
import com.buddingpoetry.pojo.Book;
import com.buddingpoetry.pojo.User;
import java.io.IOException;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.util.ArrayList;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.support.SessionStatus;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;
import java.lang.*;  
import org.springframework.ui.Model;

/**
 *
 * @author jaspr_000
 */
@Controller
public class BookController {

    @GetMapping("/book/sellbookform")
    public ModelAndView sellBookForm(ModelMap model, Book b_book) {
        ModelAndView mav = new ModelAndView("sellbookform", "b_book", b_book);
        return mav;
    }

    @PostMapping("/book/sellbookform")
    public ModelAndView sellBookProcessForm(Model model,HttpSession session, UserDao userdao, HttpServletResponse response,
            @RequestParam("uploaded_file") MultipartFile uploaded_file, ModelMap modelMap,
            @Valid @ModelAttribute("b_book") Book b_book, BookDao bookdao, BindingResult result, SessionStatus status, SubscriptionDao subscriptionDao) throws IOException {
        ModelAndView mav = new ModelAndView();
        User user = (User) session.getAttribute("user");
        try {
            if (subscriptionDao.isUserSubscribed(user)) {
                model.addAttribute("subscribed", "yes");
            } 
            if (b_book.getBook_category().equals("")) {
                String errorMsg = "Please enter Book Category";
                mav = new ModelAndView("sellbookform", "errmsg", errorMsg);
                return mav;
            }
            else if (b_book.getBook_title().equals("")) {
                String errorMsg = "Please enter Book Title";
                mav = new ModelAndView("sellbookform", "errmsg", errorMsg);
                return mav;
            } 
            else if (b_book.getSummary().equals("")) {
                String errorMsg = "Please enter Book Summary";
                mav = new ModelAndView("sellbookform", "errmsg", errorMsg);
                return mav;
            } 
            else if (uploaded_file.getBytes().length == 0) {
                String errorMsg = "Please Upload Book";
                mav = new ModelAndView("sellbookform", "errmsg", errorMsg);
                return mav;
            } 
            else if (result.hasErrors()) {
                mav = new ModelAndView("sellbookform");
                return mav;
            }
            else if (b_book != null) {
                System.out.println("+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" + b_book.getBook_category());
                byte[] filedata = uploaded_file.getBytes();
                Book book = bookdao.addBook(session, b_book.getBook_title(), b_book.getBook_category(), b_book.getSummary(), filedata, uploaded_file.getName(), userdao);
                if (book != null) {
                    String msg = bookdao.sendRequestToAdmin(session, book, userdao);
                    if (!msg.equals("Request Sent")) {
                        mav = new ModelAndView("errorPage", "errorMsg", msg);
                        return mav;
                    } else {
                        modelMap.addAttribute("b_book", b_book);
                        modelMap.addAttribute("uploaded_file", uploaded_file);
                        String successmsg = "Book Uploaded Succesfully";
                        mav = new ModelAndView("sellbookform", "successmsg", successmsg);
                        return mav;
                    }
                } else {
                    String errorMsg = "Something went wrong, Book Already Exist or No Admin Exist";
                    mav = new ModelAndView("errorPage", "errorMsg", errorMsg);
                    return mav;
                }

            } else {
                String errorMsg = "Something Went Wrong";
                mav = new ModelAndView("errorPage", "errorMsg", errorMsg);
                return mav;
            }
        } catch (Exception e) {
            String errorMsg = e.getMessage();
            mav = new ModelAndView("errorPage", "errorMsg", errorMsg);
            return mav;
        }
    }

    @GetMapping("/book/buybooklist")
    public ModelAndView buyBookList(Model model,HttpSession session, UserDao userdao, HttpServletResponse response, AdminDao admindao, BookDao bookdao, SubscriptionDao subscriptionDao) throws IOException {
        ModelAndView mav = new ModelAndView();
        try {
            User user = (User) session.getAttribute("user");
            if (subscriptionDao.isUserSubscribed(user)) {
                model.addAttribute("subscribed", "yes");
            } 
            ArrayList<Book> getBuyBook_List = bookdao.getBuyBook_List(admindao);
            if (getBuyBook_List != null) {
                mav = new ModelAndView("buybooklist", "getBuyBook_List", getBuyBook_List);
                return mav;
            } else if (getBuyBook_List == null) {
                String errorMsg = "No Books To Show";
                mav = new ModelAndView("errorPage", "errorMsg", errorMsg);
                return mav;
            } else {
                String errorMsg = "Something Went Wrong";
                mav = new ModelAndView("errorPage", "errorMsg", errorMsg);
                return mav;
            }
        } catch (Exception e) {
            String errorMsg = e.getMessage();
            mav = new ModelAndView("errorPage", "errorMsg", errorMsg);
            return mav;
        }
    }

    @GetMapping("/viewbook")
    public ModelAndView viewBook(Model model,HttpSession session, HttpServletRequest request, UserDao userdao, HttpServletResponse response, SubscriptionDao subscriptionDao, AdminDao admindao, BookDao bookdao) throws IOException {
        ModelAndView mav = new ModelAndView();
        User user = (User) session.getAttribute("user");
        try {
            if (subscriptionDao.isUserSubscribed(user)) {
                model.addAttribute("subscribed", "yes");
            } 
            String bookid = request.getParameter("bookid");
            Long book_id_long = Long.parseLong(bookid);
            Book bookbyid = bookdao.getBookByID(book_id_long);
            if (bookbyid != null) {
                mav = new ModelAndView("viewbook", "bookbyid", bookbyid);
                return mav;
            } else if (bookbyid == null) {
                String errorMsg = "No Books To Show";
                mav = new ModelAndView("errorPage", "errorMsg", errorMsg);
                return mav;
            } else {
                String errorMsg = "Something Went Wrong";
                mav = new ModelAndView("errorPage", "errorMsg", errorMsg);
                return mav;
            }
        } catch (Exception e) {
            String errorMsg = e.getMessage();
            mav = new ModelAndView("errorPage", "errorMsg", errorMsg);
            return mav;
        }
    }
}
