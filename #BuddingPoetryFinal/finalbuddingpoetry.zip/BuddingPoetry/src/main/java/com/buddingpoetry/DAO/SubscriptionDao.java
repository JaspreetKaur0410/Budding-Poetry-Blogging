/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.buddingpoetry.DAO;

import static com.buddingpoetry.DAO.DAO.getSession;
import com.buddingpoetry.pojo.User;
import com.buddingpoetry.pojo.UserSubscription;
import com.razorpay.Order;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaUpdate;
import javax.persistence.criteria.Root;
import javax.servlet.http.HttpSession;
import org.hibernate.Criteria;
import org.hibernate.criterion.Restrictions;
import org.json.JSONObject;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.stereotype.Repository;

/**
 *
 * @author jaspr_000
 */
public class SubscriptionDao extends DAO {

    public String addOrder(Order order, HttpSession session) {

        User user = (User) session.getAttribute("user");

        if (order != null) {
            UserSubscription subscription = new UserSubscription();
            try {
                System.out.println(order.get("amount").toString());
                System.out.println(order.get("created_at").toString());
                System.out.println(order.get("currency").toString());
                System.out.println(order.get("id").toString());
                System.out.println(order.get("status").toString());
                System.out.println(order.get("created_at").toString());
                System.out.println(order.get("receipt").toString());

                subscription.setAmount(Integer.parseInt(order.get("amount").toString()));
                subscription.setOrderid(order.get("id").toString());
                subscription.setPaymentid(null);
                subscription.setStatus(order.get("status").toString());
                subscription.setSusbscribed_user(user);
                subscription.setReceipt(order.get("receipt").toString());
                subscription.setSubscription_date((Date) order.get("created_at"));

                //System.out.println("&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&"+subscription+"&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&");
                begin();
                getSession().save(subscription);
                commit();
                return "Order Created";
            } catch (NumberFormatException e) {
                //System.out.println("itheeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee");
                //System.out.println("&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&" + e.getMessage() + "&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&");
                return "Exception Occurred";
            }
        }
        return "error";
    }

    public UserSubscription getOrderById(HttpSession session, String orderid) {
        begin();
        Criteria criteria = getSession().createCriteria(UserSubscription.class);
        criteria.add(Restrictions.eq("orderid", orderid));
        UserSubscription user_subscription_order = (UserSubscription) criteria.uniqueResult();
        commit();
        if (user_subscription_order == null) {
            return null;
        } else {
            return user_subscription_order;
        }
    }

    public void doPayment(UserSubscription user_subscription_order, User user) {
        ArrayList<UserSubscription> susbscription_list = getSubscriptionsList();
        
        if (user_subscription_order != null) {
            begin();
            user_subscription_order.setSusbscribed_user(user);
            user.getSusbscriptions_list().add(user_subscription_order);
            user.setSusbscriptions_list(susbscription_list);
            System.out.println("uuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuu"+user.getSusbscriptions_list());
            getSession().save(user_subscription_order);
            commit();
        }

    }

    public ArrayList<UserSubscription> getSubscriptionsList() {
        ArrayList<UserSubscription> subscriptions = new ArrayList<>();
        begin();
        Criteria criteria = getSession().createCriteria(UserSubscription.class);
        subscriptions = (ArrayList<UserSubscription>) criteria.list();
        commit();
        return subscriptions;
    }
    
    public boolean isUserSubscribed(User user){
        List<UserSubscription> susbscription_list = getSubscriptionsList();       
        for(UserSubscription us: susbscription_list){
            if(String.valueOf(us.getSusbscribed_user().getId()).equals(String.valueOf(user.getId()))){
                return true;
            }
        }
        return false;
    }
}
