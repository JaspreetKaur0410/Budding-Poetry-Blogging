/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.buddingpoetry.DAO;

import com.buddingpoetry.pojo.Likes;
import com.buddingpoetry.pojo.Post;
import com.buddingpoetry.pojo.User;
import com.buddingpoetry.pojo.PostCategory;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import javax.persistence.Query;
import javax.servlet.http.HttpSession;

import org.hibernate.Criteria;
import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.criterion.MatchMode;
import org.hibernate.criterion.Restrictions;

/**
 *
 * @author jaspr_000
 */
public class PostDao extends DAO {

    public String createPost(String postname, String postcontent,
            Date createddate, User user, String[] categories, CategoryDao categoeydao) {
        try {
            Post post = new Post();

            ArrayList<Post> postslist = categoeydao.getPostList();

            for (String category : categories) {
                if (!categoeydao.isCategoryVaid(category)) {
                    return "Category Not Valid, It doesnot exist";
                } else {
                    for (PostCategory postcategory : categoeydao.getCategoryList()) {

                        if (String.valueOf(postcategory.getCategoryname()).equals(category)) {
                            if (!post.getCategories().contains(postcategory)) {
                                post.getCategories().add(postcategory);
                                if (!postslist.contains(post)) {
                                    postslist.add(post);

                                } else {
                                    return "post already exist";
                                }
                            } else {
                                return "Category Added Twice";
                            }
                            postcategory.setPosts(postslist);
                        }
                    }
                    post.setPostname(postname);
                    post.setContent(postcontent);
                    post.setCreatedDate(createddate);
                    post.setUserid(user.getId());
                    post.setPost_user(user);
                    user.getPostslist().add(post);
                    begin();
                    getSession().save(post);
                    commit();
                    return "Post Created";
                }
            }

        } catch (Exception e) {
            return e.getMessage();
        }
        return null;
    }

    public ArrayList<PostCategory> getPostCategoryList(Post post) {

        ArrayList<PostCategory> categories = new ArrayList<>();
        begin();
        Criteria criteria = getSession().createCriteria(PostCategory.class
        );
        categories = (ArrayList<PostCategory>) criteria.list();
        commit();
        return categories;
    }

    public ArrayList<Post> getPostList() {

        ArrayList<Post> posts = new ArrayList<>();
        begin();
        Criteria criteria = getSession().createCriteria(Post.class
        );
        posts = (ArrayList<Post>) criteria.list();
        commit();
        return posts;
    }

    public Post deletePost(int id) {
        try {
            begin();
            Criteria crit = getSession().createCriteria(Post.class);
            crit.add(Restrictions.eq("postid", id));
            Post post_res = (Post) crit.uniqueResult();
            getSession().delete(post_res);
            commit();
            return post_res;
        } catch (Exception e) {
            return null;
        }
    }

    public Post getPostById(int id) {
        Criteria crit = getSession().createCriteria(Post.class);
        crit.add(Restrictions.eq("postid", id));
        Post post = (Post) crit.uniqueResult();
        return post;
    }

    public String updatePost(String posttitle, String[] categories, String postcontent, Date Createdate, Post post, User user, CategoryDao categorydao) {

        try {
            post.setPostname(posttitle);
            post.setContent(postcontent);
            post.setCreatedDate(Createdate);
                   
            for (String c : categories) {
                if (!categorydao.isCategoryVaid(c)) {
                    return "Category Selected NOT VALID";
                } else {
                    for (PostCategory postCategory : categorydao.getCategoryList()) {
                        if (String.valueOf(postCategory.getCategoryname()).equals(c)) {
                            post.getCategories().add(postCategory);
                        }
                    }
                    post.setPost_user(user);
                    user.getPostslist().add(post);
                    Session session = getSession();
                    Transaction tx = session.beginTransaction();
                    session.update(post);
                    tx.commit();
                    return "post updated";
                }
            }

        } catch (HibernateException e) {
            e.printStackTrace();
            rollback();
        } finally {
            close();
        }
        return null;
    }

    public Likes likePost(Post post, User user) {

        try {
            int flag = 0;
            List<Likes> userswholikedpost = user.getLikes0npostbyuserlist();
            List<Likes> likesonpost = post.getLikeslist();

            // check if user already liked the post
            for (Likes liking : userswholikedpost) {
                if (!String.valueOf(liking.getLikedby_user().getId()).equals(String.valueOf(user.getId()))
                        || !String.valueOf(liking.getPost().getPostid()).equals(String.valueOf(post.getPostid()))) {
                    flag = 0;
                } else {
                    flag = 1;
                }

            }
            System.out.println("+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" + flag + "+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++");
            if (flag == 0 || userswholikedpost == null) {
                Likes like = new Likes();
                like.setLikedby_user(user);
                like.setPost(post);

                likesonpost.add(like);
                post.setLikeslist(likesonpost);
                userswholikedpost.add(like);
                Session session = getSession();
                Transaction tx = session.beginTransaction();
                session.save(post);
                tx.commit();
                return like;
            }

            //System.out.println("**************************************************************" + like.getLikedby_user() + "*****************************************************************************************************************");
        } catch (HibernateException e) {
            e.printStackTrace();
            rollback();
            return null;
        } finally {
            close();
        }
        return null;
    }

    public boolean isUserLikePost(User user, Post post) {

        for (Likes like : post.getLikeslist()) {
            if (String.valueOf(like.getLikedby_user().getId()).equals(String.valueOf(user.getId()))) {
                return true;
            }
        }
        return false;
    }

    public List<Post> searchPostByWriter(String keyword) {

        List<Post> posts = new ArrayList<Post>();
        System.out.println("&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&" + keyword);
        try {
            begin();
            Criteria crit = getSession().createCriteria(Post.class);
            crit.createAlias("post_user", "pu");
            posts = crit.add(Restrictions.like("pu.username", "%" + keyword + "%")).list();
            System.out.println("++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" + posts);
            commit();
            return posts;
        } catch (HibernateException e) {

            e.printStackTrace();
            rollback();
            return null;

        } finally {
            close();
        }
    }

    public List<Post> searchPostByCategory(String keyword, CategoryDao categorydao) {

        List<Post> posts = new ArrayList<Post>();
        //System.out.println("&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&"+keyword);
        try {
            for (PostCategory category : categorydao.getCategoryList()) {

                begin();
                Criteria crit = getSession().createCriteria(Post.class);
                crit.createAlias("post_user", "pu");
                posts = crit.add(Restrictions.like("pu.username", "%" + keyword + "%")).list();
                System.out.println("++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" + posts);
                commit();

            }
            return posts;
        } catch (HibernateException e) {

            e.printStackTrace();
            rollback();
            return null;

        } finally {
            close();
        }
    }

}
