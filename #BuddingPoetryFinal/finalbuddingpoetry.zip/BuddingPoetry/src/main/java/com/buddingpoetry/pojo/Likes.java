/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.buddingpoetry.pojo;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

/**
 *
 * @author jaspr_000
 */
@Entity
@Table(name = "likes")
public class Likes {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int likeid;
    
    @ManyToOne(fetch = FetchType.EAGER, targetEntity = Post.class)
    @JoinColumn(name="post_id")
    private Post post_mapping;
    
    @ManyToOne(fetch = FetchType.EAGER, targetEntity = User.class)
    @JoinColumn(name="likedbyuser_id")
    private User likedby_user;

    
    public Likes(){
        
    }

    public int getLikeid() {
        return likeid;
    }

    public void setLikeid(int likeid) {
        this.likeid = likeid;
    }

    public Post getPost() {
        return post_mapping;
    }

    public void setPost(Post post) {
        this.post_mapping = post;
    }

    public Post getPost_mapping() {
        return post_mapping;
    }

    public void setPost_mapping(Post post_mapping) {
        this.post_mapping = post_mapping;
    }

    public User getLikedby_user() {
        return likedby_user;
    }

    public void setLikedby_user(User likedby_user) {
        this.likedby_user = likedby_user;
    }
    

    @Override
    public String toString() {
        return "Likes{" + "likeid=" + likeid + ", post=" + post_mapping + '}';
    }
    
}
