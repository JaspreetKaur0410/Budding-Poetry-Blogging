/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.buddingpoetry.pojo;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotEmpty;
import org.hibernate.annotations.Cascade;
import org.hibernate.annotations.DynamicUpdate;
import org.hibernate.annotations.Fetch;
import org.hibernate.annotations.FetchMode;
import org.hibernate.annotations.OptimisticLockType;
import org.hibernate.annotations.OptimisticLocking;

/**
 *
 * @author jaspr_000
 */
@Entity
@Table(name = "post")
@OptimisticLocking(type = OptimisticLockType.DIRTY)
@DynamicUpdate
public class Post {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int postid;

    @NotBlank(message = "Please provide title")
    private String postname;

    @Fetch(FetchMode.SELECT)
    @ManyToMany(mappedBy="posts", fetch = FetchType.EAGER, cascade = CascadeType.PERSIST)
    private List<PostCategory> categories = new ArrayList<>();
    
    @NotBlank(message = "Please write a post")
    private String content;

    @Temporal(TemporalType.DATE)
    private Date createdDate;
    @Transient
    private int userid;
    
    @ManyToOne
    @JoinColumn(name="user_id")
    private User post_user;
    
    
    @OneToMany(cascade = CascadeType.ALL,mappedBy = "post_mapping", fetch=FetchType.EAGER)
    private List<Likes> likeslistonpost = new ArrayList<>();

    public Post() {

    }

    public int getPostid() {
        return postid;
    }

    public void setPostid(int postid) {
        this.postid = postid;
    }

    public String getPostname() {
        return postname;
    }

    public void setPostname(String postname) {
        this.postname = postname;
    }

    public List<PostCategory> getCategories() {
        return categories;
    }

    public void setCategories(List<PostCategory> categories) {
        this.categories = categories;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public Date getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(Date createdDate) {
        this.createdDate = createdDate;
    }

    public int getUserid() {
        return userid;
    }

    public void setUserid(int userid) {
        this.userid = userid;
    }

    public User getPost_user() {
        return post_user;
    }

    public void setPost_user(User post_user) {
        this.post_user = post_user;
    }

    public List<Likes> getLikeslist() {
        return likeslistonpost;
    }

    public void setLikeslist(List<Likes> likeslist) {
        this.likeslistonpost = likeslist;
    }

   

    @Override
    public String toString() {
        return postname;
    }

}
