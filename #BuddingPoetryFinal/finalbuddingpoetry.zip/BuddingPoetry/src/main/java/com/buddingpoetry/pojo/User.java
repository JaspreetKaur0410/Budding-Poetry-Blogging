/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.buddingpoetry.pojo;

import java.util.ArrayList;
import java.util.List;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Transient;
import javax.validation.constraints.Email;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotEmpty;
import org.hibernate.annotations.DynamicUpdate;
import org.hibernate.annotations.NaturalId;
import org.hibernate.annotations.OptimisticLockType;
import org.hibernate.annotations.OptimisticLocking;

/**
 *
 * @author jaspr_000
 */
@Entity
@OptimisticLocking(type = OptimisticLockType.DIRTY)
@Table(name = "tbl_user")
@DynamicUpdate
public class User {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;

    @Email(message = "Please enter a valid email address!")
    @NotEmpty(message = "Please enter your email address!")
    @NaturalId(mutable = false)
    @Column(unique = true, nullable = false)
    private String email;

    @NotBlank(message = "Please provide username")
    private String username;
    @NotBlank(message = "Please enter password")
    private String password;

    @Transient
    private String cnfrmpwd;
    private String role;

    @OneToMany(cascade = CascadeType.ALL, mappedBy = "post_user")
    private List<Post> postslist = new ArrayList<>();

    @OneToMany(cascade = CascadeType.ALL, mappedBy = "likedby_user")
    private List<Likes> likes0npostbyuserlist = new ArrayList<>();
//////////////////////////////////////////////////////////////////////////////////////////////
    /* @OneToOne(mappedBy = "subscribed_user")
    @JoinColumn(name="subscribed_user_id")
    private UserSubscription user_subscription;*/
//////////////////////////////////////////////////////////////////////////////////////////////

    /*//////////////////////////////////////////////////////////////////////////////////////*/
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "susbscribed_user")
    private List<UserSubscription> susbscriptions_list = new ArrayList<>();

    @OneToMany(cascade = CascadeType.ALL, mappedBy = "order_user")
    private List<CartOrder> cartorders = new ArrayList<>();


    /**
     * ***************************************************************************************
     */
    @OneToMany(cascade = CascadeType.PERSIST, mappedBy = "admin_user_requestedby")
    private List<AdminRequests> admin_request_list = new ArrayList<>();

    @OneToMany(cascade = CascadeType.ALL, mappedBy = "buy_user_item")
    private List<Item> user_items = new ArrayList<>();  

    public User() {

    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getRole() {
        return role;
    }

    public void setRole(String role) {
        this.role = role;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getCnfrmpwd() {
        return cnfrmpwd;
    }

    public void setCnfrmpwd(String cnfrmpwd) {
        this.cnfrmpwd = cnfrmpwd;
    }

    public List<Post> getPostslist() {
        return postslist;
    }

    public void setPostslist(List<Post> postslist) {
        this.postslist = postslist;
    }

    public List<Likes> getLikes0npostbyuserlist() {
        return likes0npostbyuserlist;
    }

    public void setLikes0npostbyuserlist(List<Likes> likes0npostbyuserlist) {
        this.likes0npostbyuserlist = likes0npostbyuserlist;
    }

    public List<UserSubscription> getSusbscriptions_list() {
        return susbscriptions_list;
    }

    public void setSusbscriptions_list(List<UserSubscription> susbscriptions_list) {
        this.susbscriptions_list = susbscriptions_list;
    }

    public List<AdminRequests> getAdmin_request_list() {
        return admin_request_list;
    }

    public void setAdmin_request_list(List<AdminRequests> admin_request_list) {
        this.admin_request_list = admin_request_list;
    }

    public List<Item> getUser_items() {
        return user_items;
    }

    public void setUser_items(List<Item> user_items) {
        this.user_items = user_items;
    }

    public List<CartOrder> getCartorders() {
        return cartorders;
    }

    public void setCartorders(List<CartOrder> cartorders) {
        this.cartorders = cartorders;
    }

    @Override
    public String toString() {
        return "User{" + "username=" + username + '}';
    }

}
